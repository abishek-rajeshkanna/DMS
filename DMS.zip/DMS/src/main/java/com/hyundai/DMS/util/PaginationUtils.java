package com.hyundai.DMS.util;

import com.hyundai.DMS.dto.response.PagedResponse;
import org.springframework.data.domain.Page;
public class PaginationUtils {

    public static <T> PagedResponse<T> toPagedResponse(Page<T> page) {
        return PagedResponse.<T>builder()
                .content(page.getContent())
                .page(page.getNumber())
                .size(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .last(page.isLast())
                .build();
    }
}
