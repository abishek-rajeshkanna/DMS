package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.*;
import com.hyundai.DMS.domain.enums.ServiceTicketStatus;
import com.hyundai.DMS.dto.request.ServiceTicketFilter;
import com.hyundai.DMS.dto.request.ServiceTicketRequest;
import com.hyundai.DMS.dto.response.PagedResponse;
import com.hyundai.DMS.dto.response.ServiceTicketResponse;
import com.hyundai.DMS.exception.ConflictException;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.exception.ValidationException;
import com.hyundai.DMS.repository.*;
import com.hyundai.DMS.security.DmsUserDetails;
import com.hyundai.DMS.specification.ServiceTicketSpecification;
import com.hyundai.DMS.util.HtmlSanitizer;
import com.hyundai.DMS.util.PaginationUtils;
import com.hyundai.DMS.util.SequenceGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class ServiceTicketService {

    private final ServiceTicketRepository serviceTicketRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;
    private final DealershipRepository dealershipRepository;
    private final SequenceGenerator sequenceGenerator;
    private final NotificationService notificationService;
    private final AuditService auditService;
    private final HtmlSanitizer htmlSanitizer;

    @Transactional
    public ServiceTicketResponse createTicket(ServiceTicketRequest request, DmsUserDetails principal) {
        Dealership dealership = dealershipRepository.findById(request.getDealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));

        if (!principal.isSuperAdmin() && !dealership.getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Cannot create ticket in another dealership");
        }

        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));

        User assignedTo = null;
        if (request.getAssignedToUserId() != null) {
            assignedTo = userRepository.findById(request.getAssignedToUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("Assigned user not found"));
        }

        String ticketNumber = sequenceGenerator.nextTicketNumber(LocalDate.now());

        ServiceTicket ticket = ServiceTicket.builder()
                .dealership(dealership)
                .ticketNumber(ticketNumber)
                .customer(customer)
                .assignedTo(assignedTo)
                .vehicleMake(htmlSanitizer.sanitize(request.getVehicleMake()))
                .vehicleModel(htmlSanitizer.sanitize(request.getVehicleModel()))
                .vehicleYear(request.getVehicleYear())
                .vehicleVin(request.getVehicleVin())
                .licensePlate(request.getLicensePlate())
                .odometerIn(request.getOdometerIn())
                .status(ServiceTicketStatus.OPEN)
                .priority(request.getPriority())
                .serviceType(request.getServiceType())
                .diagnosis(htmlSanitizer.sanitize(request.getDiagnosis()))
                .customerApproval(request.getCustomerApproval())
                .dropOffAt(request.getDropOffAt())
                .promisedAt(request.getPromisedAt())
                .notes(htmlSanitizer.sanitize(request.getNotes()))
                .build();

        ticket = serviceTicketRepository.save(ticket);

        if (assignedTo != null) {
            notificationService.send(assignedTo.getId(), "New Service Ticket Assigned",
                    "Ticket " + ticketNumber + " has been assigned to you",
                    "SERVICE_TICKET", ticket.getId());
        }

        auditService.log(principal.getUserId(), dealership.getId(), "CREATE_SERVICE_TICKET",
                "service_tickets", ticket.getId(), null, null, null, null);

        return ServiceTicketResponse.from(ticket);
    }

    public PagedResponse<ServiceTicketResponse> listTickets(ServiceTicketFilter filter, Pageable pageable, DmsUserDetails principal) {
        if (!principal.isSuperAdmin()) {
            filter.setDealershipId(principal.getDealershipId());
        }

        Specification<ServiceTicket> spec = Specification
                .where(ServiceTicketSpecification.hasDealership(filter.getDealershipId()))
                .and(ServiceTicketSpecification.hasStatus(filter.getStatus()))
                .and(ServiceTicketSpecification.hasPriority(filter.getPriority()))
                .and(ServiceTicketSpecification.hasServiceType(filter.getServiceType()))
                .and(ServiceTicketSpecification.assignedTo(filter.getAssignedToUserId()))
                .and(ServiceTicketSpecification.hasCustomer(filter.getCustomerId()));

        return PaginationUtils.toPagedResponse(
                serviceTicketRepository.findAll(spec, pageable).map(ServiceTicketResponse::from)
        );
    }

    public ServiceTicketResponse getTicket(Long id, DmsUserDetails principal) {
        ServiceTicket ticket = findById(id);
        enforceScope(ticket, principal);
        return ServiceTicketResponse.from(ticket);
    }

    @Transactional
    public ServiceTicketResponse updateTicket(Long id, ServiceTicketRequest request, DmsUserDetails principal) {
        ServiceTicket ticket = findById(id);
        enforceScope(ticket, principal);

        User assignedTo = null;
        if (request.getAssignedToUserId() != null) {
            assignedTo = userRepository.findById(request.getAssignedToUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("Assigned user not found"));
        }

        ticket.setVehicleMake(htmlSanitizer.sanitize(request.getVehicleMake()));
        ticket.setVehicleModel(htmlSanitizer.sanitize(request.getVehicleModel()));
        ticket.setVehicleYear(request.getVehicleYear());
        ticket.setVehicleVin(request.getVehicleVin());
        ticket.setLicensePlate(request.getLicensePlate());
        ticket.setOdometerIn(request.getOdometerIn());
        ticket.setPriority(request.getPriority());
        ticket.setServiceType(request.getServiceType());
        ticket.setDiagnosis(htmlSanitizer.sanitize(request.getDiagnosis()));
        ticket.setCustomerApproval(request.getCustomerApproval());
        ticket.setDropOffAt(request.getDropOffAt());
        ticket.setPromisedAt(request.getPromisedAt());
        ticket.setAssignedTo(assignedTo);
        ticket.setNotes(htmlSanitizer.sanitize(request.getNotes()));

        ticket = serviceTicketRepository.save(ticket);
        auditService.log(principal.getUserId(), ticket.getDealership().getId(), "UPDATE_SERVICE_TICKET",
                "service_tickets", ticket.getId(), null, null, null, null);

        return ServiceTicketResponse.from(ticket);
    }

    @Transactional
    public ServiceTicketResponse transitionStatus(Long id, ServiceTicketStatus newStatus,
                                                   LocalDateTime completedAt, LocalDateTime deliveredAt,
                                                   Integer odometerOut, DmsUserDetails principal) {
        ServiceTicket ticket = findById(id);
        enforceScope(ticket, principal);

        // Guard conditions
        if (newStatus == ServiceTicketStatus.IN_PROGRESS) {
            if (ticket.getDiagnosis() == null || ticket.getDiagnosis().isBlank()) {
                throw new ValidationException("Diagnosis is required before moving to IN_PROGRESS");
            }
        } else if (newStatus == ServiceTicketStatus.COMPLETED) {
            if (!Boolean.TRUE.equals(ticket.getCustomerApproval())) {
                throw new ValidationException("Customer approval is required before completing");
            }
            ticket.setCompletedAt(completedAt != null ? completedAt : LocalDateTime.now());
        } else if (newStatus == ServiceTicketStatus.DELIVERED) {
            if (odometerOut == null) {
                throw new ValidationException("Odometer out is required for delivery");
            }
            if (ticket.getOdometerIn() != null && odometerOut < ticket.getOdometerIn()) {
                throw new ValidationException("Odometer out must be >= odometer in");
            }
            ticket.setOdometerOut(odometerOut);
            ticket.setDeliveredAt(deliveredAt != null ? deliveredAt : LocalDateTime.now());
        } else if (newStatus == ServiceTicketStatus.CANCELLED) {
            if (ticket.getStatus() == ServiceTicketStatus.DELIVERED) {
                throw new ConflictException("Cannot cancel a delivered ticket");
            }
        }

        ticket.setStatus(newStatus);
        ticket = serviceTicketRepository.save(ticket);

        if (ticket.getAssignedTo() != null) {
            notificationService.send(ticket.getAssignedTo().getId(), "Ticket Status Updated",
                    "Ticket " + ticket.getTicketNumber() + " status changed to " + newStatus.name(),
                    "SERVICE_TICKET", ticket.getId());
        }

        auditService.log(principal.getUserId(), ticket.getDealership().getId(), "TRANSITION_TICKET_STATUS",
                "service_tickets", ticket.getId(), null, null, null, null);

        return ServiceTicketResponse.from(ticket);
    }

    @Transactional
    public ServiceTicketResponse cancelTicket(Long id, DmsUserDetails principal) {
        ServiceTicket ticket = findById(id);
        enforceScope(ticket, principal);

        if (ticket.getStatus() == ServiceTicketStatus.DELIVERED) {
            throw new ConflictException("Cannot cancel a delivered ticket");
        }

        ticket.setStatus(ServiceTicketStatus.CANCELLED);
        ticket = serviceTicketRepository.save(ticket);
        auditService.log(principal.getUserId(), ticket.getDealership().getId(), "CANCEL_SERVICE_TICKET",
                "service_tickets", ticket.getId(), null, null, null, null);

        return ServiceTicketResponse.from(ticket);
    }

    private void enforceScope(ServiceTicket ticket, DmsUserDetails principal) {
        if (principal.isSuperAdmin()) return;
        if (!ticket.getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Access denied to ticket in another dealership");
        }
    }

    private ServiceTicket findById(Long id) {
        return serviceTicketRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Service ticket not found with id: " + id));
    }
}
