package com.hyundai.DMS.util;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class SequenceGenerator {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private final ConcurrentHashMap<String, AtomicInteger> orderCounters = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, AtomicInteger> ticketCounters = new ConcurrentHashMap<>();

    public String nextOrderNumber(LocalDate date) {
        String key = date.format(DATE_FMT);
        int seq = orderCounters.computeIfAbsent(key, k -> new AtomicInteger(0)).incrementAndGet();
        return String.format("ORD-%s-%04d", key, seq);
    }

    public String nextTicketNumber(LocalDate date) {
        String key = date.format(DATE_FMT);
        int seq = ticketCounters.computeIfAbsent(key, k -> new AtomicInteger(0)).incrementAndGet();
        return String.format("SVC-%s-%04d", key, seq);
    }
}
