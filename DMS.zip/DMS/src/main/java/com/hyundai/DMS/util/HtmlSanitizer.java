package com.hyundai.DMS.util;

import org.springframework.stereotype.Component;

@Component
public class HtmlSanitizer {

    private static final java.util.regex.Pattern HTML_TAG_PATTERN =
            java.util.regex.Pattern.compile("<[^>]*>", java.util.regex.Pattern.DOTALL);

    public String sanitize(String input) {
        if (input == null) return null;
        return HTML_TAG_PATTERN.matcher(input).replaceAll("");
    }
}
