package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.Dealership;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class DealershipResponse {
    private Long id;
    private String name;
    private String email;
    private String phone;
    private String address;
    private String city;
    private String state;
    private String licenseNo;
    private Boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static DealershipResponse from(Dealership d) {
        return DealershipResponse.builder()
                .id(d.getId())
                .name(d.getName())
                .email(d.getEmail())
                .phone(d.getPhone())
                .address(d.getAddress())
                .city(d.getCity())
                .state(d.getState())
                .licenseNo(d.getLicenseNo())
                .isActive(d.getIsActive())
                .createdAt(d.getCreatedAt())
                .updatedAt(d.getUpdatedAt())
                .build();
    }
}
