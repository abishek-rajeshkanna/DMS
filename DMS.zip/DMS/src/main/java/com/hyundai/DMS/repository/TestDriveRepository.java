package com.hyundai.DMS.repository;

import com.hyundai.DMS.domain.entity.TestDrive;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface TestDriveRepository extends JpaRepository<TestDrive, Long>, JpaSpecificationExecutor<TestDrive> {
}
