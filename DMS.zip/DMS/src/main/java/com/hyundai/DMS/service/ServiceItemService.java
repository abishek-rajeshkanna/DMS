package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.ServiceItem;
import com.hyundai.DMS.domain.entity.ServiceTicket;
import com.hyundai.DMS.domain.enums.ServiceItemType;
import com.hyundai.DMS.domain.enums.ServiceTicketStatus;
import com.hyundai.DMS.dto.request.ServiceItemRequest;
import com.hyundai.DMS.dto.response.ServiceItemResponse;
import com.hyundai.DMS.exception.ConflictException;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.repository.ServiceItemRepository;
import com.hyundai.DMS.repository.ServiceTicketRepository;
import com.hyundai.DMS.security.DmsUserDetails;
import com.hyundai.DMS.util.HtmlSanitizer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ServiceItemService {

    private static final Set<ServiceTicketStatus> TERMINAL_STATUSES = Set.of(
            ServiceTicketStatus.COMPLETED,
            ServiceTicketStatus.CANCELLED,
            ServiceTicketStatus.DELIVERED
    );

    private final ServiceItemRepository serviceItemRepository;
    private final ServiceTicketRepository serviceTicketRepository;
    private final AuditService auditService;
    private final HtmlSanitizer htmlSanitizer;

    @Transactional
    public ServiceItemResponse addItem(Long ticketId, ServiceItemRequest request, DmsUserDetails principal) {
        ServiceTicket ticket = findTicket(ticketId);
        enforceScope(ticket, principal);
        rejectIfTerminal(ticket);

        BigDecimal lineTotal = request.getUnitCost().multiply(request.getQuantity());

        ServiceItem item = ServiceItem.builder()
                .ticket(ticket)
                .itemType(request.getItemType())
                .description(htmlSanitizer.sanitize(request.getDescription()))
                .partNumber(request.getPartNumber())
                .unitCost(request.getUnitCost())
                .quantity(request.getQuantity())
                .lineTotal(lineTotal)
                .build();

        item = serviceItemRepository.save(item);
        recomputeTicketTotals(ticket);
        serviceTicketRepository.save(ticket);

        auditService.log(principal.getUserId(), ticket.getDealership().getId(), "ADD_SERVICE_ITEM",
                "service_items", item.getId(), null, null, null, null);

        return ServiceItemResponse.from(item);
    }

    @Transactional
    public ServiceItemResponse updateItem(Long ticketId, Long itemId, ServiceItemRequest request, DmsUserDetails principal) {
        ServiceTicket ticket = findTicket(ticketId);
        enforceScope(ticket, principal);
        rejectIfTerminal(ticket);

        ServiceItem item = serviceItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Service item not found with id: " + itemId));

        if (!item.getTicket().getId().equals(ticketId)) {
            throw new ResourceNotFoundException("Service item does not belong to ticket " + ticketId);
        }

        BigDecimal lineTotal = request.getUnitCost().multiply(request.getQuantity());

        item.setItemType(request.getItemType());
        item.setDescription(htmlSanitizer.sanitize(request.getDescription()));
        item.setPartNumber(request.getPartNumber());
        item.setUnitCost(request.getUnitCost());
        item.setQuantity(request.getQuantity());
        item.setLineTotal(lineTotal);

        item = serviceItemRepository.save(item);
        recomputeTicketTotals(ticket);
        serviceTicketRepository.save(ticket);

        auditService.log(principal.getUserId(), ticket.getDealership().getId(), "UPDATE_SERVICE_ITEM",
                "service_items", item.getId(), null, null, null, null);

        return ServiceItemResponse.from(item);
    }

    @Transactional
    public void removeItem(Long ticketId, Long itemId, DmsUserDetails principal) {
        ServiceTicket ticket = findTicket(ticketId);
        enforceScope(ticket, principal);
        rejectIfTerminal(ticket);

        ServiceItem item = serviceItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Service item not found with id: " + itemId));

        if (!item.getTicket().getId().equals(ticketId)) {
            throw new ResourceNotFoundException("Service item does not belong to ticket " + ticketId);
        }

        serviceItemRepository.delete(item);
        recomputeTicketTotals(ticket);
        serviceTicketRepository.save(ticket);

        auditService.log(principal.getUserId(), ticket.getDealership().getId(), "REMOVE_SERVICE_ITEM",
                "service_items", itemId, null, null, null, null);
    }

    public List<ServiceItemResponse> listItems(Long ticketId, DmsUserDetails principal) {
        ServiceTicket ticket = findTicket(ticketId);
        enforceScope(ticket, principal);
        return serviceItemRepository.findAllByTicketId(ticketId)
                .stream().map(ServiceItemResponse::from).toList();
    }

    // --- helpers ---

    private void recomputeTicketTotals(ServiceTicket ticket) {
        List<ServiceItem> items = serviceItemRepository.findAllByTicketId(ticket.getId());

        BigDecimal totalParts = items.stream()
                .filter(i -> i.getItemType() != ServiceItemType.LABOR)
                .map(ServiceItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalLabor = items.stream()
                .filter(i -> i.getItemType() == ServiceItemType.LABOR)
                .map(ServiceItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        ticket.setTotalParts(totalParts);
        ticket.setTotalLabor(totalLabor);
        ticket.setTotalCost(totalParts.add(totalLabor));
    }

    private void rejectIfTerminal(ServiceTicket ticket) {
        if (TERMINAL_STATUSES.contains(ticket.getStatus())) {
            throw new ConflictException("Cannot modify items on a ticket with status: " + ticket.getStatus());
        }
    }

    private void enforceScope(ServiceTicket ticket, DmsUserDetails principal) {
        if (principal.isSuperAdmin()) return;
        if (!ticket.getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Access denied to ticket in another dealership");
        }
    }

    private ServiceTicket findTicket(Long ticketId) {
        return serviceTicketRepository.findById(ticketId)
                .orElseThrow(() -> new ResourceNotFoundException("Service ticket not found with id: " + ticketId));
    }
}
