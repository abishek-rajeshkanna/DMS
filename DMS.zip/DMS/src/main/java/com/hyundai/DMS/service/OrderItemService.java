package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.Inventory;
import com.hyundai.DMS.domain.entity.Order;
import com.hyundai.DMS.domain.entity.OrderItem;
import com.hyundai.DMS.domain.enums.OrderItemType;
import com.hyundai.DMS.domain.enums.OrderStatus;
import com.hyundai.DMS.dto.request.OrderItemRequest;
import com.hyundai.DMS.dto.response.OrderItemResponse;
import com.hyundai.DMS.exception.ConflictException;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.repository.InventoryRepository;
import com.hyundai.DMS.repository.OrderItemRepository;
import com.hyundai.DMS.repository.OrderRepository;
import com.hyundai.DMS.security.DmsUserDetails;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderItemService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final InventoryRepository inventoryRepository;
    private final OrderService orderService;

    @Transactional
    public OrderItemResponse addItem(Long orderId, OrderItemRequest request, DmsUserDetails principal) {
        Order order = findOrder(orderId);
        enforceScope(order, principal);
        requireDraft(order);

        Inventory inventory = null;
        if (request.getItemType() == OrderItemType.VEHICLE) {
            if (request.getInventoryId() == null) {
                throw new com.hyundai.DMS.exception.ValidationException("Inventory ID is required for VEHICLE items");
            }
            inventory = inventoryRepository.findById(request.getInventoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Inventory not found"));
            if (!inventory.getDealership().getId().equals(order.getDealership().getId())) {
                throw new ForbiddenException("Vehicle does not belong to the same dealership as the order");
            }
        }

        BigDecimal discount = request.getDiscount() != null ? request.getDiscount() : BigDecimal.ZERO;
        BigDecimal lineTotal = request.getUnitPrice()
                .multiply(BigDecimal.valueOf(request.getQuantity()))
                .subtract(discount);

        OrderItem item = OrderItem.builder()
                .order(order)
                .itemType(request.getItemType())
                .inventory(inventory)
                .description(request.getDescription())
                .unitPrice(request.getUnitPrice())
                .quantity(request.getQuantity())
                .discount(discount)
                .lineTotal(lineTotal)
                .build();

        item = orderItemRepository.save(item);
        orderService.recomputeFinancials(order);
        orderRepository.save(order);

        return OrderItemResponse.from(item);
    }

    @Transactional
    public OrderItemResponse updateItem(Long orderId, Long itemId, OrderItemRequest request, DmsUserDetails principal) {
        Order order = findOrder(orderId);
        enforceScope(order, principal);
        requireDraft(order);

        OrderItem item = orderItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Order item not found"));

        if (!item.getOrder().getId().equals(orderId)) {
            throw new ForbiddenException("Item does not belong to this order");
        }

        BigDecimal discount = request.getDiscount() != null ? request.getDiscount() : BigDecimal.ZERO;
        BigDecimal lineTotal = request.getUnitPrice()
                .multiply(BigDecimal.valueOf(request.getQuantity()))
                .subtract(discount);

        item.setItemType(request.getItemType());
        item.setDescription(request.getDescription());
        item.setUnitPrice(request.getUnitPrice());
        item.setQuantity(request.getQuantity());
        item.setDiscount(discount);
        item.setLineTotal(lineTotal);

        item = orderItemRepository.save(item);
        orderService.recomputeFinancials(order);
        orderRepository.save(order);

        return OrderItemResponse.from(item);
    }

    @Transactional
    public void removeItem(Long orderId, Long itemId, DmsUserDetails principal) {
        Order order = findOrder(orderId);
        enforceScope(order, principal);
        requireDraft(order);

        OrderItem item = orderItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Order item not found"));

        if (!item.getOrder().getId().equals(orderId)) {
            throw new ForbiddenException("Item does not belong to this order");
        }

        orderItemRepository.delete(item);
        orderService.recomputeFinancials(order);
        orderRepository.save(order);
    }

    public List<OrderItemResponse> listItems(Long orderId, DmsUserDetails principal) {
        Order order = findOrder(orderId);
        enforceScope(order, principal);
        return orderItemRepository.findAllByOrderId(orderId).stream()
                .map(OrderItemResponse::from)
                .collect(Collectors.toList());
    }

    private void requireDraft(Order order) {
        if (order.getStatus() != OrderStatus.DRAFT) {
            throw new ConflictException("Items can only be modified on draft orders");
        }
    }

    private void enforceScope(Order order, DmsUserDetails principal) {
        if (principal.isSuperAdmin()) return;
        if (!order.getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Access denied to order in another dealership");
        }
    }

    private Order findOrder(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));
    }
}
