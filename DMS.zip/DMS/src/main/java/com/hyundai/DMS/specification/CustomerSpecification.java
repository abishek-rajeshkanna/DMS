package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.Customer;
import com.hyundai.DMS.domain.enums.CustomerStatus;
import org.springframework.data.jpa.domain.Specification;

public class CustomerSpecification {

    private CustomerSpecification() {}

    public static Specification<Customer> hasDealership(Long dealershipId) {
        return (root, query, cb) -> dealershipId == null ? null
                : cb.equal(root.get("dealership").get("id"), dealershipId);
    }

    public static Specification<Customer> hasStatus(CustomerStatus status) {
        return (root, query, cb) -> status == null ? null
                : cb.equal(root.get("status"), status);
    }

    public static Specification<Customer> hasSource(String source) {
        return (root, query, cb) -> source == null ? null
                : cb.equal(cb.lower(root.get("source")), source.toLowerCase());
    }

    public static Specification<Customer> assignedTo(Long userId) {
        return (root, query, cb) -> userId == null ? null
                : cb.equal(root.get("assignedTo").get("id"), userId);
    }

    public static Specification<Customer> assignedToOrUnassigned(Long userId) {
        return (root, query, cb) -> userId == null ? null
                : cb.or(
                    cb.equal(root.get("assignedTo").get("id"), userId),
                    cb.isNull(root.get("assignedTo"))
                );
    }

    public static Specification<Customer> search(String search) {
        return (root, query, cb) -> {
            if (search == null || search.isBlank()) return null;
            String pattern = "%" + search.toLowerCase() + "%";
            return cb.or(
                    cb.like(cb.lower(root.get("firstName")), pattern),
                    cb.like(cb.lower(root.get("lastName")), pattern),
                    cb.like(cb.lower(root.get("email")), pattern),
                    cb.like(cb.lower(root.get("phone")), pattern)
            );
        };
    }
}
