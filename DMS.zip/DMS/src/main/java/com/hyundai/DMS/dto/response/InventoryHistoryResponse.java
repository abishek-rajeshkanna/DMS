package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.InventoryHistory;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class InventoryHistoryResponse {
    private Long id;
    private Long inventoryId;
    private String fieldName;
    private String oldValue;
    private String newValue;
    private Long changedById;
    private String changedByName;
    private String reason;
    private LocalDateTime createdAt;

    public static InventoryHistoryResponse from(InventoryHistory h) {
        return InventoryHistoryResponse.builder()
                .id(h.getId())
                .inventoryId(h.getInventory() != null ? h.getInventory().getId() : null)
                .fieldName(h.getFieldName())
                .oldValue(h.getOldValue())
                .newValue(h.getNewValue())
                .changedById(h.getChangedBy() != null ? h.getChangedBy().getId() : null)
                .changedByName(h.getChangedBy() != null
                        ? h.getChangedBy().getFirstName() + " " + h.getChangedBy().getLastName() : null)
                .reason(h.getReason())
                .createdAt(h.getCreatedAt())
                .build();
    }
}
