package com.hyundai.DMS.domain.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum ServiceType {
    MAINTENANCE("maintenance"),
    REPAIR("repair"),
    INSPECTION("inspection"),
    RECALL("recall"),
    WARRANTY("warranty"),
    OTHER("other")
    ;

    private final String value;

    ServiceType(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }
}
