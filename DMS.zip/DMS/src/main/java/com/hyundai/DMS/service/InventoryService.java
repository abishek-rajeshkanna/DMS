package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.Dealership;
import com.hyundai.DMS.domain.entity.Inventory;
import com.hyundai.DMS.domain.entity.InventoryHistory;
import com.hyundai.DMS.domain.entity.User;
import com.hyundai.DMS.domain.enums.InventoryStatus;
import com.hyundai.DMS.domain.enums.Role;
import com.hyundai.DMS.dto.request.InventoryFilter;
import com.hyundai.DMS.dto.request.InventoryRequest;
import com.hyundai.DMS.dto.response.InventoryHistoryResponse;
import com.hyundai.DMS.dto.response.InventoryResponse;
import com.hyundai.DMS.dto.response.PagedResponse;
import com.hyundai.DMS.exception.ConflictException;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.repository.DealershipRepository;
import com.hyundai.DMS.repository.InventoryHistoryRepository;
import com.hyundai.DMS.repository.InventoryRepository;
import com.hyundai.DMS.repository.UserRepository;
import com.hyundai.DMS.security.DmsUserDetails;
import com.hyundai.DMS.specification.InventorySpecification;
import com.hyundai.DMS.util.HtmlSanitizer;
import com.hyundai.DMS.util.PaginationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class InventoryService {

    private final InventoryRepository inventoryRepository;
    private final InventoryHistoryRepository inventoryHistoryRepository;
    private final DealershipRepository dealershipRepository;
    private final UserRepository userRepository;
    private final AuditService auditService;
    private final HtmlSanitizer htmlSanitizer;

    @CacheEvict(value = "inventoryList", allEntries = true)
    @Transactional
    public InventoryResponse createInventory(InventoryRequest request, DmsUserDetails principal) {
        if (inventoryRepository.existsByVin(request.getVin())) {
            throw new ConflictException("Vehicle with VIN " + request.getVin() + " already exists");
        }

        Dealership dealership = dealershipRepository.findById(request.getDealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));

        if (!principal.isSuperAdmin() && !dealership.getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Cannot add inventory to another dealership");
        }

        User changedBy = userRepository.findById(principal.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Inventory inventory = Inventory.builder()
                .dealership(dealership)
                .vin(request.getVin().toUpperCase())
                .make(htmlSanitizer.sanitize(request.getMake()))
                .model(htmlSanitizer.sanitize(request.getModel()))
                .variant(htmlSanitizer.sanitize(request.getVariant()))
                .year(request.getYear())
                .fuelType(request.getFuelType())
                .transmission(request.getTransmission())
                .bodyType(request.getBodyType())
                .color(htmlSanitizer.sanitize(request.getColor()))
                .mileage(request.getMileage())
                .conditionType(request.getConditionType())
                .status(request.getStatus())
                .costPrice(request.getCostPrice())
                .sellingPrice(request.getSellingPrice())
                .intakeDate(request.getIntakeDate())
                .notes(htmlSanitizer.sanitize(request.getNotes()))
                .build();

        inventory = inventoryRepository.save(inventory);

        // Write initial history for key fields
        writeHistory(inventory, changedBy, "status", null, inventory.getStatus().name(), "Initial intake");
        writeHistory(inventory, changedBy, "sellingPrice", null, inventory.getSellingPrice().toString(), "Initial intake");

        auditService.log(principal.getUserId(), dealership.getId(), "CREATE_INVENTORY",
                "inventory", inventory.getId(), null, null, null, null);

        return InventoryResponse.from(inventory);
    }

    @Cacheable(value = "inventoryList")
    public PagedResponse<InventoryResponse> listInventory(InventoryFilter filter, Pageable pageable) {
        Specification<Inventory> spec = Specification
                .where(InventorySpecification.hasDealership(filter.getDealershipId()))
                .and(InventorySpecification.hasMake(filter.getMake()))
                .and(InventorySpecification.hasModel(filter.getModel()))
                .and(InventorySpecification.hasYear(filter.getYear()))
                .and(InventorySpecification.hasFuelType(filter.getFuelType()))
                .and(InventorySpecification.hasTransmission(filter.getTransmission()))
                .and(InventorySpecification.hasBodyType(filter.getBodyType()))
                .and(InventorySpecification.hasCondition(filter.getConditionType()))
                .and(InventorySpecification.hasStatus(filter.getStatus()))
                .and(InventorySpecification.minPrice(filter.getMinPrice()))
                .and(InventorySpecification.maxPrice(filter.getMaxPrice()))
                .and(InventorySpecification.search(filter.getSearch()));

        return PaginationUtils.toPagedResponse(
                inventoryRepository.findAll(spec, pageable).map(InventoryResponse::from)
        );
    }

    public InventoryResponse getInventory(Long id, DmsUserDetails principal) {
        Inventory inventory = findById(id);
        enforceScope(inventory, principal);
        return InventoryResponse.from(inventory);
    }

    @CacheEvict(value = "inventoryList", allEntries = true)
    @Transactional
    public InventoryResponse updateInventory(Long id, InventoryRequest request, DmsUserDetails principal) {
        Inventory inventory = findById(id);
        enforceScope(inventory, principal);

        // Sold status lock: only ADMIN/MANAGER/SUPER_ADMIN can change status of sold inventory
        if (inventory.getStatus() == InventoryStatus.SOLD
                && request.getStatus() != InventoryStatus.SOLD
                && !principal.isManagerOrAbove()) {
            throw new ForbiddenException("Only managers and above can change status of sold inventory");
        }

        User changedBy = userRepository.findById(principal.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        List<InventoryHistory> historyEntries = new ArrayList<>();

        // Diff and record changes
        if (!inventory.getStatus().equals(request.getStatus())) {
            historyEntries.add(buildHistory(inventory, changedBy, "status",
                    inventory.getStatus().name(), request.getStatus().name(), null));
        }
        if (!inventory.getSellingPrice().equals(request.getSellingPrice())) {
            historyEntries.add(buildHistory(inventory, changedBy, "sellingPrice",
                    inventory.getSellingPrice().toString(), request.getSellingPrice().toString(), null));
        }
        if (!inventory.getCostPrice().equals(request.getCostPrice())) {
            historyEntries.add(buildHistory(inventory, changedBy, "costPrice",
                    inventory.getCostPrice().toString(), request.getCostPrice().toString(), null));
        }
        if (request.getMileage() != null && !request.getMileage().equals(inventory.getMileage())) {
            historyEntries.add(buildHistory(inventory, changedBy, "mileage",
                    String.valueOf(inventory.getMileage()), String.valueOf(request.getMileage()), null));
        }

        inventory.setMake(htmlSanitizer.sanitize(request.getMake()));
        inventory.setModel(htmlSanitizer.sanitize(request.getModel()));
        inventory.setVariant(htmlSanitizer.sanitize(request.getVariant()));
        inventory.setYear(request.getYear());
        inventory.setFuelType(request.getFuelType());
        inventory.setTransmission(request.getTransmission());
        inventory.setBodyType(request.getBodyType());
        inventory.setColor(htmlSanitizer.sanitize(request.getColor()));
        inventory.setMileage(request.getMileage());
        inventory.setConditionType(request.getConditionType());
        inventory.setStatus(request.getStatus());
        inventory.setCostPrice(request.getCostPrice());
        inventory.setSellingPrice(request.getSellingPrice());
        inventory.setIntakeDate(request.getIntakeDate());
        inventory.setNotes(htmlSanitizer.sanitize(request.getNotes()));

        inventory = inventoryRepository.save(inventory);

        if (!historyEntries.isEmpty()) {
            inventoryHistoryRepository.saveAll(historyEntries);
        }

        auditService.log(principal.getUserId(), inventory.getDealership().getId(), "UPDATE_INVENTORY",
                "inventory", inventory.getId(), null, null, null, null);

        return InventoryResponse.from(inventory);
    }

    @CacheEvict(value = "inventoryList", allEntries = true)
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','SUPER_ADMIN')")
    @Transactional
    public void deleteInventory(Long id, DmsUserDetails principal) {
        Inventory inventory = findById(id);
        enforceScope(inventory, principal);
        inventory.setStatus(InventoryStatus.INACTIVE);
        inventoryRepository.save(inventory);
        auditService.log(principal.getUserId(), inventory.getDealership().getId(), "DELETE_INVENTORY",
                "inventory", inventory.getId(), null, null, null, null);
    }

    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    public PagedResponse<InventoryHistoryResponse> getInventoryHistory(Long id, Pageable pageable, DmsUserDetails principal) {
        Inventory inventory = findById(id);
        enforceScope(inventory, principal);
        return PaginationUtils.toPagedResponse(
                inventoryHistoryRepository.findAllByInventoryIdOrderByCreatedAtDesc(id, pageable)
                        .map(InventoryHistoryResponse::from)
        );
    }

    private void writeHistory(Inventory inventory, User changedBy, String field, String oldVal, String newVal, String reason) {
        inventoryHistoryRepository.save(buildHistory(inventory, changedBy, field, oldVal, newVal, reason));
    }

    private InventoryHistory buildHistory(Inventory inventory, User changedBy, String field, String oldVal, String newVal, String reason) {
        return InventoryHistory.builder()
                .inventory(inventory)
                .changedBy(changedBy)
                .fieldName(field)
                .oldValue(oldVal)
                .newValue(newVal)
                .reason(reason)
                .build();
    }

    private void enforceScope(Inventory inventory, DmsUserDetails principal) {
        if (principal.isSuperAdmin()) return;
        if (!inventory.getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Access denied to inventory in another dealership");
        }
    }

    private Inventory findById(Long id) {
        return inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found with id: " + id));
    }
}
