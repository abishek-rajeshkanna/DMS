package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.*;
import com.hyundai.DMS.domain.enums.InventoryStatus;
import com.hyundai.DMS.domain.enums.TestDriveStatus;
import com.hyundai.DMS.dto.request.TestDriveFilter;
import com.hyundai.DMS.dto.request.TestDriveRequest;
import com.hyundai.DMS.dto.response.PagedResponse;
import com.hyundai.DMS.dto.response.TestDriveResponse;
import com.hyundai.DMS.exception.ConflictException;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.exception.ValidationException;
import com.hyundai.DMS.repository.*;
import com.hyundai.DMS.security.DmsUserDetails;
import com.hyundai.DMS.specification.TestDriveSpecification;
import com.hyundai.DMS.util.PaginationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class TestDriveService {

    private final TestDriveRepository testDriveRepository;
    private final InventoryRepository inventoryRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;
    private final DealershipRepository dealershipRepository;
    private final NotificationService notificationService;
    private final AuditService auditService;

    @Transactional
    public TestDriveResponse scheduleTestDrive(TestDriveRequest request, DmsUserDetails principal) {
        Dealership dealership = dealershipRepository.findById(request.getDealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));

        if (!principal.isSuperAdmin() && !dealership.getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Cannot schedule test drive in another dealership");
        }

        Inventory inventory = inventoryRepository.findById(request.getInventoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found"));

        if (inventory.getStatus() != InventoryStatus.AVAILABLE && inventory.getStatus() != InventoryStatus.TEST_DRIVE) {
            throw new ConflictException("Vehicle is not available for test drive (status: " + inventory.getStatus() + ")");
        }

        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));

        User staff = userRepository.findById(request.getStaffId())
                .orElseThrow(() -> new ResourceNotFoundException("Staff user not found"));

        inventory.setStatus(InventoryStatus.TEST_DRIVE);
        inventoryRepository.save(inventory);

        TestDrive testDrive = TestDrive.builder()
                .dealership(dealership)
                .customer(customer)
                .inventory(inventory)
                .staff(staff)
                .scheduledAt(request.getScheduledAt())
                .status(TestDriveStatus.SCHEDULED)
                .odometerBefore(request.getOdometerBefore())
                .notes(request.getNotes())
                .build();

        testDrive = testDriveRepository.save(testDrive);

        notificationService.send(staff.getId(), "Test Drive Scheduled",
                "A test drive has been scheduled for " + customer.getFirstName() + " " + customer.getLastName(),
                "TEST_DRIVE", testDrive.getId());

        auditService.log(principal.getUserId(), dealership.getId(), "SCHEDULE_TEST_DRIVE",
                "test_drives", testDrive.getId(), null, null, null, null);

        return TestDriveResponse.from(testDrive);
    }

    @Transactional
    public TestDriveResponse updateTestDrive(Long id, TestDriveRequest request, DmsUserDetails principal) {
        TestDrive testDrive = findById(id);
        enforceScope(testDrive, principal);

        TestDriveStatus newStatus = request.getStatus() != null ? request.getStatus() : testDrive.getStatus();

        if (newStatus == TestDriveStatus.COMPLETED) {
            if (request.getOdometerAfter() == null || request.getOdometerBefore() == null) {
                throw new ValidationException("Odometer readings are required to complete a test drive");
            }
            if (request.getOdometerAfter() < request.getOdometerBefore()) {
                throw new ValidationException("Odometer after must be >= odometer before");
            }
            testDrive.getInventory().setStatus(InventoryStatus.AVAILABLE);
            inventoryRepository.save(testDrive.getInventory());
            testDrive.setEndedAt(request.getEndedAt());
        } else if (newStatus == TestDriveStatus.IN_PROGRESS) {
            testDrive.setStartedAt(request.getStartedAt());
        } else if (newStatus == TestDriveStatus.CANCELLED) {
            testDrive.getInventory().setStatus(InventoryStatus.AVAILABLE);
            inventoryRepository.save(testDrive.getInventory());
        }

        testDrive.setStatus(newStatus);
        testDrive.setOdometerBefore(request.getOdometerBefore());
        testDrive.setOdometerAfter(request.getOdometerAfter());
        testDrive.setNotes(request.getNotes());

        testDrive = testDriveRepository.save(testDrive);

        notificationService.send(testDrive.getStaff().getId(), "Test Drive Updated",
                "Test drive status changed to " + newStatus.name(),
                "TEST_DRIVE", testDrive.getId());

        return TestDriveResponse.from(testDrive);
    }

    @Transactional
    public TestDriveResponse cancelTestDrive(Long id, DmsUserDetails principal) {
        TestDrive testDrive = findById(id);
        enforceScope(testDrive, principal);

        if (testDrive.getStatus() == TestDriveStatus.COMPLETED) {
            throw new ConflictException("Cannot cancel a completed test drive");
        }

        testDrive.setStatus(TestDriveStatus.CANCELLED);
        testDrive.getInventory().setStatus(InventoryStatus.AVAILABLE);
        inventoryRepository.save(testDrive.getInventory());
        testDrive = testDriveRepository.save(testDrive);

        return TestDriveResponse.from(testDrive);
    }

    public PagedResponse<TestDriveResponse> listTestDrives(TestDriveFilter filter, Pageable pageable, DmsUserDetails principal) {
        if (!principal.isSuperAdmin()) {
            filter.setDealershipId(principal.getDealershipId());
        }

        Specification<TestDrive> spec = Specification
                .where(TestDriveSpecification.hasDealership(filter.getDealershipId()))
                .and(TestDriveSpecification.hasStatus(filter.getStatus()))
                .and(TestDriveSpecification.hasCustomer(filter.getCustomerId()))
                .and(TestDriveSpecification.hasInventory(filter.getInventoryId()))
                .and(TestDriveSpecification.hasStaff(filter.getStaffId()))
                .and(TestDriveSpecification.scheduledAfter(filter.getScheduledFrom()))
                .and(TestDriveSpecification.scheduledBefore(filter.getScheduledTo()));

        return PaginationUtils.toPagedResponse(
                testDriveRepository.findAll(spec, pageable).map(TestDriveResponse::from)
        );
    }

    public TestDriveResponse getTestDrive(Long id, DmsUserDetails principal) {
        TestDrive testDrive = findById(id);
        enforceScope(testDrive, principal);
        return TestDriveResponse.from(testDrive);
    }

    private void enforceScope(TestDrive testDrive, DmsUserDetails principal) {
        if (principal.isSuperAdmin()) return;
        if (!testDrive.getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Access denied to test drive in another dealership");
        }
    }

    private TestDrive findById(Long id) {
        return testDriveRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Test drive not found with id: " + id));
    }
}
