package com.hyundai.DMS.dto.request;

import com.hyundai.DMS.domain.enums.UserStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UserStatusRequest {

    @NotNull(message = "Status is required")
    private UserStatus status;
}
