package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.TestDrive;
import com.hyundai.DMS.domain.enums.TestDriveStatus;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;

public class TestDriveSpecification {

    private TestDriveSpecification() {}

    public static Specification<TestDrive> hasDealership(Long dealershipId) {
        return (root, query, cb) -> dealershipId == null ? null
                : cb.equal(root.get("dealership").get("id"), dealershipId);
    }

    public static Specification<TestDrive> hasStatus(TestDriveStatus status) {
        return (root, query, cb) -> status == null ? null
                : cb.equal(root.get("status"), status);
    }

    public static Specification<TestDrive> hasCustomer(Long customerId) {
        return (root, query, cb) -> customerId == null ? null
                : cb.equal(root.get("customer").get("id"), customerId);
    }

    public static Specification<TestDrive> hasInventory(Long inventoryId) {
        return (root, query, cb) -> inventoryId == null ? null
                : cb.equal(root.get("inventory").get("id"), inventoryId);
    }

    public static Specification<TestDrive> hasStaff(Long staffId) {
        return (root, query, cb) -> staffId == null ? null
                : cb.equal(root.get("staff").get("id"), staffId);
    }

    public static Specification<TestDrive> scheduledAfter(LocalDateTime from) {
        return (root, query, cb) -> from == null ? null
                : cb.greaterThanOrEqualTo(root.get("scheduledAt"), from);
    }

    public static Specification<TestDrive> scheduledBefore(LocalDateTime to) {
        return (root, query, cb) -> to == null ? null
                : cb.lessThanOrEqualTo(root.get("scheduledAt"), to);
    }
}
