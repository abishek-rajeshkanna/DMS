package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.Inventory;
import com.hyundai.DMS.domain.enums.*;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
public class InventoryResponse {
    private Long id;
    private Long dealershipId;
    private String dealershipName;
    private String vin;
    private String make;
    private String model;
    private String variant;
    private Integer year;
    private FuelType fuelType;
    private Transmission transmission;
    private BodyType bodyType;
    private String color;
    private Integer mileage;
    private InventoryCondition conditionType;
    private InventoryStatus status;
    private BigDecimal costPrice;
    private BigDecimal sellingPrice;
    private LocalDate intakeDate;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static InventoryResponse from(Inventory i) {
        return InventoryResponse.builder()
                .id(i.getId())
                .dealershipId(i.getDealership() != null ? i.getDealership().getId() : null)
                .dealershipName(i.getDealership() != null ? i.getDealership().getName() : null)
                .vin(i.getVin())
                .make(i.getMake())
                .model(i.getModel())
                .variant(i.getVariant())
                .year(i.getYear())
                .fuelType(i.getFuelType())
                .transmission(i.getTransmission())
                .bodyType(i.getBodyType())
                .color(i.getColor())
                .mileage(i.getMileage())
                .conditionType(i.getConditionType())
                .status(i.getStatus())
                .costPrice(i.getCostPrice())
                .sellingPrice(i.getSellingPrice())
                .intakeDate(i.getIntakeDate())
                .notes(i.getNotes())
                .createdAt(i.getCreatedAt())
                .updatedAt(i.getUpdatedAt())
                .build();
    }
}
