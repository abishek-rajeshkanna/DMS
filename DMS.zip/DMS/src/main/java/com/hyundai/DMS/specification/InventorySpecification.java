package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.Inventory;
import com.hyundai.DMS.domain.enums.*;
import org.springframework.data.jpa.domain.Specification;

import java.math.BigDecimal;

public class InventorySpecification {

    private InventorySpecification() {}

    public static Specification<Inventory> hasDealership(Long dealershipId) {
        return (root, query, cb) -> dealershipId == null ? null
                : cb.equal(root.get("dealership").get("id"), dealershipId);
    }

    public static Specification<Inventory> hasMake(String make) {
        return (root, query, cb) -> make == null ? null
                : cb.equal(cb.lower(root.get("make")), make.toLowerCase());
    }

    public static Specification<Inventory> hasModel(String model) {
        return (root, query, cb) -> model == null ? null
                : cb.equal(cb.lower(root.get("model")), model.toLowerCase());
    }

    public static Specification<Inventory> hasYear(Integer year) {
        return (root, query, cb) -> year == null ? null
                : cb.equal(root.get("year"), year);
    }

    public static Specification<Inventory> hasFuelType(FuelType fuelType) {
        return (root, query, cb) -> fuelType == null ? null
                : cb.equal(root.get("fuelType"), fuelType);
    }

    public static Specification<Inventory> hasTransmission(Transmission transmission) {
        return (root, query, cb) -> transmission == null ? null
                : cb.equal(root.get("transmission"), transmission);
    }

    public static Specification<Inventory> hasBodyType(BodyType bodyType) {
        return (root, query, cb) -> bodyType == null ? null
                : cb.equal(root.get("bodyType"), bodyType);
    }

    public static Specification<Inventory> hasCondition(InventoryCondition condition) {
        return (root, query, cb) -> condition == null ? null
                : cb.equal(root.get("conditionType"), condition);
    }

    public static Specification<Inventory> hasStatus(InventoryStatus status) {
        return (root, query, cb) -> status == null ? null
                : cb.equal(root.get("status"), status);
    }

    public static Specification<Inventory> minPrice(BigDecimal minPrice) {
        return (root, query, cb) -> minPrice == null ? null
                : cb.greaterThanOrEqualTo(root.get("sellingPrice"), minPrice);
    }

    public static Specification<Inventory> maxPrice(BigDecimal maxPrice) {
        return (root, query, cb) -> maxPrice == null ? null
                : cb.lessThanOrEqualTo(root.get("sellingPrice"), maxPrice);
    }

    public static Specification<Inventory> search(String search) {
        return (root, query, cb) -> {
            if (search == null || search.isBlank()) return null;
            String pattern = "%" + search.toLowerCase() + "%";
            return cb.or(
                    cb.like(cb.lower(root.get("make")), pattern),
                    cb.like(cb.lower(root.get("model")), pattern),
                    cb.like(cb.lower(root.get("variant")), pattern)
            );
        };
    }
}
