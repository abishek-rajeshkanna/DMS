package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.Dealership;
import org.springframework.data.jpa.domain.Specification;

public class DealershipSpecification {

    private DealershipSpecification() {}

    public static Specification<Dealership> hasName(String name) {
        return (root, query, cb) -> name == null ? null
                : cb.like(cb.lower(root.get("name")), "%" + name.toLowerCase() + "%");
    }

    public static Specification<Dealership> hasCity(String city) {
        return (root, query, cb) -> city == null ? null
                : cb.equal(cb.lower(root.get("city")), city.toLowerCase());
    }

    public static Specification<Dealership> hasState(String state) {
        return (root, query, cb) -> state == null ? null
                : cb.equal(cb.lower(root.get("state")), state.toLowerCase());
    }

    public static Specification<Dealership> isActive(Boolean active) {
        return (root, query, cb) -> active == null ? null
                : cb.equal(root.get("isActive"), active);
    }
}
