package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.ServiceItem;
import com.hyundai.DMS.domain.enums.ServiceItemType;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
public class ServiceItemResponse {
    private Long id;
    private Long ticketId;
    private ServiceItemType itemType;
    private String description;
    private String partNumber;
    private BigDecimal unitCost;
    private BigDecimal quantity;
    private BigDecimal lineTotal;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static ServiceItemResponse from(ServiceItem i) {
        return ServiceItemResponse.builder()
                .id(i.getId())
                .ticketId(i.getTicket() != null ? i.getTicket().getId() : null)
                .itemType(i.getItemType())
                .description(i.getDescription())
                .partNumber(i.getPartNumber())
                .unitCost(i.getUnitCost())
                .quantity(i.getQuantity())
                .lineTotal(i.getLineTotal())
                .createdAt(i.getCreatedAt())
                .updatedAt(i.getUpdatedAt())
                .build();
    }
}
