package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.Order;
import com.hyundai.DMS.domain.entity.Payment;
import com.hyundai.DMS.domain.enums.OrderStatus;
import com.hyundai.DMS.domain.enums.PaymentStatus;
import com.hyundai.DMS.dto.request.PaymentFilter;
import com.hyundai.DMS.dto.request.PaymentRequest;
import com.hyundai.DMS.dto.response.PagedResponse;
import com.hyundai.DMS.dto.response.PaymentResponse;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.repository.OrderRepository;
import com.hyundai.DMS.repository.PaymentRepository;
import com.hyundai.DMS.security.DmsUserDetails;
import com.hyundai.DMS.specification.PaymentSpecification;
import com.hyundai.DMS.util.PaginationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;
    private final AuditService auditService;

    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','SUPER_ADMIN')")
    @Transactional
    public PaymentResponse recordPayment(PaymentRequest request, DmsUserDetails principal) {
        Order order = orderRepository.findById(request.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));

        if (!principal.isSuperAdmin() && !order.getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Cannot record payment for order in another dealership");
        }

        Payment payment = Payment.builder()
                .order(order)
                .amount(request.getAmount())
                .method(request.getMethod())
                .status(request.getStatus())
                .referenceNo(request.getReferenceNo())
                .notes(request.getNotes())
                .paidAt(request.getPaidAt() != null ? request.getPaidAt() : LocalDateTime.now())
                .build();

        payment = paymentRepository.save(payment);

        if (request.getStatus() == PaymentStatus.COMPLETED) {
            checkAndAutoProcessOrder(order);
            auditService.log(principal.getUserId(), order.getDealership().getId(), "PAYMENT_COMPLETED",
                    "payments", payment.getId(), null, null, null, null);
        }

        return PaymentResponse.from(payment);
    }

    public PagedResponse<PaymentResponse> listPayments(PaymentFilter filter, Pageable pageable, DmsUserDetails principal) {
        Specification<Payment> spec = Specification
                .where(PaymentSpecification.hasOrder(filter.getOrderId()))
                .and(PaymentSpecification.hasStatus(filter.getStatus()))
                .and(PaymentSpecification.hasMethod(filter.getMethod()));

        return PaginationUtils.toPagedResponse(
                paymentRepository.findAll(spec, pageable).map(PaymentResponse::from)
        );
    }

    public PaymentResponse getPayment(Long id, DmsUserDetails principal) {
        Payment payment = findById(id);
        if (!principal.isSuperAdmin() && !payment.getOrder().getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Access denied to payment in another dealership");
        }
        return PaymentResponse.from(payment);
    }

    @Transactional
    public PaymentResponse updatePayment(Long id, PaymentRequest request, DmsUserDetails principal) {
        Payment payment = findById(id);
        Order order = payment.getOrder();

        if (!principal.isSuperAdmin() && !order.getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Access denied to payment in another dealership");
        }

        payment.setAmount(request.getAmount());
        payment.setMethod(request.getMethod());
        payment.setStatus(request.getStatus());
        payment.setReferenceNo(request.getReferenceNo());
        payment.setNotes(request.getNotes());
        if (request.getPaidAt() != null) payment.setPaidAt(request.getPaidAt());

        payment = paymentRepository.save(payment);

        if (request.getStatus() == PaymentStatus.COMPLETED) {
            checkAndAutoProcessOrder(order);
            auditService.log(principal.getUserId(), order.getDealership().getId(), "PAYMENT_UPDATED_COMPLETED",
                    "payments", payment.getId(), null, null, null, null);
        }

        return PaymentResponse.from(payment);
    }

    private void checkAndAutoProcessOrder(Order order) {
        if (order.getStatus() != OrderStatus.CONFIRMED) return;
        BigDecimal totalPaid = paymentRepository.sumAmountByOrderIdAndStatus(order.getId(), PaymentStatus.COMPLETED);
        if (totalPaid != null && order.getTotalAmount() != null
                && totalPaid.compareTo(order.getTotalAmount()) >= 0) {
            order.setStatus(OrderStatus.PROCESSING);
            orderRepository.save(order);
        }
    }

    private Payment findById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));
    }
}
