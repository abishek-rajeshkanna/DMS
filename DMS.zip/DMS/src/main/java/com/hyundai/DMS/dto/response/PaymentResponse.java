package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.Payment;
import com.hyundai.DMS.domain.enums.PaymentMethod;
import com.hyundai.DMS.domain.enums.PaymentStatus;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
public class PaymentResponse {
    private Long id;
    private Long orderId;
    private String orderNumber;
    private BigDecimal amount;
    private PaymentMethod method;
    private PaymentStatus status;
    private String referenceNo;
    private String notes;
    private LocalDateTime paidAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static PaymentResponse from(Payment p) {
        return PaymentResponse.builder()
                .id(p.getId())
                .orderId(p.getOrder() != null ? p.getOrder().getId() : null)
                .orderNumber(p.getOrder() != null ? p.getOrder().getOrderNumber() : null)
                .amount(p.getAmount())
                .method(p.getMethod())
                .status(p.getStatus())
                .referenceNo(p.getReferenceNo())
                .notes(p.getNotes())
                .paidAt(p.getPaidAt())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}
