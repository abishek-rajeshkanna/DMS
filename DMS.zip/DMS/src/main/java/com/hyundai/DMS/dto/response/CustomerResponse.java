package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.Customer;
import com.hyundai.DMS.domain.enums.CustomerStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class CustomerResponse {
    private Long id;
    private Long dealershipId;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private CustomerStatus status;
    private String source;
    private Long assignedToId;
    private String assignedToName;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static CustomerResponse from(Customer c) {
        return CustomerResponse.builder()
                .id(c.getId())
                .dealershipId(c.getDealership() != null ? c.getDealership().getId() : null)
                .firstName(c.getFirstName())
                .lastName(c.getLastName())
                .email(c.getEmail())
                .phone(c.getPhone())
                .status(c.getStatus())
                .source(c.getSource())
                .assignedToId(c.getAssignedTo() != null ? c.getAssignedTo().getId() : null)
                .assignedToName(c.getAssignedTo() != null
                        ? c.getAssignedTo().getFirstName() + " " + c.getAssignedTo().getLastName() : null)
                .notes(c.getNotes())
                .createdAt(c.getCreatedAt())
                .updatedAt(c.getUpdatedAt())
                .build();
    }
}
