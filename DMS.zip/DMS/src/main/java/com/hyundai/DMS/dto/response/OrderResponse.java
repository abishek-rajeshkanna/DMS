package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.Order;
import com.hyundai.DMS.domain.enums.OrderStatus;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
public class OrderResponse {
    private Long id;
    private Long dealershipId;
    private String orderNumber;
    private Long customerId;
    private String customerName;
    private Long salespersonId;
    private String salespersonName;
    private OrderStatus status;
    private LocalDate orderDate;
    private BigDecimal subtotal;
    private BigDecimal discountAmount;
    private BigDecimal taxRate;
    private BigDecimal taxAmount;
    private BigDecimal tradeInValue;
    private BigDecimal totalAmount;
    private String cancellationReason;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static OrderResponse from(Order o) {
        return OrderResponse.builder()
                .id(o.getId())
                .dealershipId(o.getDealership() != null ? o.getDealership().getId() : null)
                .orderNumber(o.getOrderNumber())
                .customerId(o.getCustomer() != null ? o.getCustomer().getId() : null)
                .customerName(o.getCustomer() != null
                        ? o.getCustomer().getFirstName() + " " + o.getCustomer().getLastName() : null)
                .salespersonId(o.getSalesperson() != null ? o.getSalesperson().getId() : null)
                .salespersonName(o.getSalesperson() != null
                        ? o.getSalesperson().getFirstName() + " " + o.getSalesperson().getLastName() : null)
                .status(o.getStatus())
                .orderDate(o.getOrderDate())
                .subtotal(o.getSubtotal())
                .discountAmount(o.getDiscountAmount())
                .taxRate(o.getTaxRate())
                .taxAmount(o.getTaxAmount())
                .tradeInValue(o.getTradeInValue())
                .totalAmount(o.getTotalAmount())
                .cancellationReason(o.getCancellationReason())
                .notes(o.getNotes())
                .createdAt(o.getCreatedAt())
                .updatedAt(o.getUpdatedAt())
                .build();
    }
}
