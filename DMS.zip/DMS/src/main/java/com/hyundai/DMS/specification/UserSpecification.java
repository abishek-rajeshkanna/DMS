package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.User;
import com.hyundai.DMS.domain.enums.Role;
import com.hyundai.DMS.domain.enums.UserStatus;
import org.springframework.data.jpa.domain.Specification;

public class UserSpecification {

    private UserSpecification() {}

    public static Specification<User> hasDealership(Long dealershipId) {
        return (root, query, cb) -> dealershipId == null ? null
                : cb.equal(root.get("dealership").get("id"), dealershipId);
    }

    public static Specification<User> hasRole(Role role) {
        return (root, query, cb) -> role == null ? null
                : cb.equal(root.get("role"), role);
    }

    public static Specification<User> hasStatus(UserStatus status) {
        return (root, query, cb) -> status == null ? null
                : cb.equal(root.get("status"), status);
    }

    public static Specification<User> searchByName(String search) {
        return (root, query, cb) -> {
            if (search == null || search.isBlank()) return null;
            String pattern = "%" + search.toLowerCase() + "%";
            return cb.or(
                    cb.like(cb.lower(root.get("firstName")), pattern),
                    cb.like(cb.lower(root.get("lastName")), pattern),
                    cb.like(cb.lower(root.get("email")), pattern)
            );
        };
    }
}
