package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.Dealership;
import com.hyundai.DMS.domain.entity.User;
import com.hyundai.DMS.domain.enums.Role;
import com.hyundai.DMS.domain.enums.UserStatus;
import com.hyundai.DMS.dto.request.UserFilter;
import com.hyundai.DMS.dto.request.UserRequest;
import com.hyundai.DMS.dto.response.PagedResponse;
import com.hyundai.DMS.dto.response.UserResponse;
import com.hyundai.DMS.exception.ConflictException;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.repository.DealershipRepository;
import com.hyundai.DMS.repository.UserRepository;
import com.hyundai.DMS.security.DmsUserDetails;
import com.hyundai.DMS.specification.UserSpecification;
import com.hyundai.DMS.util.HtmlSanitizer;
import com.hyundai.DMS.util.PaginationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final DealershipRepository dealershipRepository;
    private final PasswordEncoder passwordEncoder;
    private final TokenService tokenService;
    private final AuditService auditService;
    private final HtmlSanitizer htmlSanitizer;

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','MANAGER')")
    @Transactional
    public UserResponse createUser(UserRequest request, DmsUserDetails principal) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new ConflictException("User with this email already exists");
        }
        if (request.getPassword() == null || request.getPassword().isBlank()) {
            throw new com.hyundai.DMS.exception.ValidationException("Password is required when creating a user");
        }

        Dealership dealership = null;
        if (request.getDealershipId() != null) {
            dealership = dealershipRepository.findById(request.getDealershipId())
                    .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));
        } else if (request.getRole() != Role.SUPER_ADMIN) {
            throw new com.hyundai.DMS.exception.ValidationException("Dealership is required for non-super_admin users");
        }

        // MANAGER can only create within their own dealership
        if (principal.getRole() == Role.MANAGER) {
            if (dealership == null || !dealership.getId().equals(principal.getDealershipId())) {
                throw new ForbiddenException("Managers can only create users in their own dealership");
            }
        }

        User user = User.builder()
                .dealership(dealership)
                .firstName(htmlSanitizer.sanitize(request.getFirstName()))
                .lastName(htmlSanitizer.sanitize(request.getLastName()))
                .email(request.getEmail().toLowerCase())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .status(UserStatus.ACTIVE)
                .failedLoginAttempts(0)
                .build();

        user = userRepository.save(user);
        auditService.log(principal.getUserId(), dealershipId(principal), "CREATE_USER",
                "users", user.getId(), null, null, null, null);

        return UserResponse.from(user);
    }

    public PagedResponse<UserResponse> listUsers(UserFilter filter, Pageable pageable, DmsUserDetails principal) {
        // MANAGER is scoped to their dealership
        if (principal.getRole() == Role.MANAGER) {
            filter.setDealershipId(principal.getDealershipId());
        }
        // ADMIN is scoped to their dealership (unless SUPER_ADMIN)
        if (principal.getRole() == Role.ADMIN) {
            filter.setDealershipId(principal.getDealershipId());
        }

        Specification<User> spec = Specification
                .where(UserSpecification.hasDealership(filter.getDealershipId()))
                .and(UserSpecification.hasRole(filter.getRole()))
                .and(UserSpecification.hasStatus(filter.getStatus()))
                .and(UserSpecification.searchByName(filter.getSearch()));

        return PaginationUtils.toPagedResponse(
                userRepository.findAll(spec, pageable).map(UserResponse::from)
        );
    }

    public UserResponse getUser(Long id, DmsUserDetails principal) {
        User user = findById(id);
        enforceScope(user, principal);
        return UserResponse.from(user);
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','MANAGER')")
    @Transactional
    public UserResponse updateUser(Long id, UserRequest request, DmsUserDetails principal) {
        User user = findById(id);
        enforceScope(user, principal);

        if (!user.getEmail().equalsIgnoreCase(request.getEmail())
                && userRepository.existsByEmail(request.getEmail())) {
            throw new ConflictException("User with this email already exists");
        }

        user.setFirstName(htmlSanitizer.sanitize(request.getFirstName()));
        user.setLastName(htmlSanitizer.sanitize(request.getLastName()));
        user.setEmail(request.getEmail().toLowerCase());
        user.setRole(request.getRole());

        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        }

        user = userRepository.save(user);
        auditService.log(principal.getUserId(), dealershipId(principal), "UPDATE_USER",
                "users", user.getId(), null, null, null, null);

        return UserResponse.from(user);
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','MANAGER')")
    @Transactional
    public UserResponse changeStatus(Long id, UserStatus newStatus, DmsUserDetails principal) {
        User user = findById(id);
        enforceScope(user, principal);

        user.setStatus(newStatus);
        user = userRepository.save(user);

        if (newStatus == UserStatus.SUSPENDED) {
            tokenService.revokeAllForUser(id);
        }

        auditService.log(principal.getUserId(), dealershipId(principal), "CHANGE_USER_STATUS",
                "users", user.getId(), null, null, null, null);

        return UserResponse.from(user);
    }

    private void enforceScope(User user, DmsUserDetails principal) {
        if (principal.isSuperAdmin()) return;
        Long userDealershipId = user.getDealership() != null ? user.getDealership().getId() : null;
        if (!principal.getDealershipId().equals(userDealershipId)) {
            throw new ForbiddenException("Access denied to user in another dealership");
        }
    }

    private User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    private Long dealershipId(DmsUserDetails principal) {
        return principal.getDealershipId();
    }
}
