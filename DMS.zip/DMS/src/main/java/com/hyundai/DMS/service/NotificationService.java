package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.Notification;
import com.hyundai.DMS.domain.entity.User;
import com.hyundai.DMS.dto.response.NotificationResponse;
import com.hyundai.DMS.dto.response.PagedResponse;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.repository.NotificationRepository;
import com.hyundai.DMS.repository.UserRepository;
import com.hyundai.DMS.util.PaginationUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    @Async("notificationExecutor")
    public void send(Long recipientUserId, String title, String message, String referenceType, Long referenceId) {
        try {
            User user = userRepository.findById(recipientUserId).orElse(null);
            if (user == null) {
                log.warn("Cannot send notification: user {} not found", recipientUserId);
                return;
            }
            Notification notification = Notification.builder()
                    .user(user)
                    .title(title)
                    .message(message)
                    .isRead(false)
                    .referenceType(referenceType)
                    .referenceId(referenceId)
                    .createdAt(LocalDateTime.now())
                    .build();
            notificationRepository.save(notification);
        } catch (Exception e) {
            log.error("Failed to send notification to user {}: {}", recipientUserId, e.getMessage(), e);
        }
    }

    public PagedResponse<NotificationResponse> listNotifications(Long userId, Boolean isRead, Pageable pageable) {
        if (isRead != null) {
            return PaginationUtils.toPagedResponse(
                    notificationRepository.findAllByUserIdAndIsRead(userId, isRead, pageable)
                            .map(NotificationResponse::from)
            );
        }
        return PaginationUtils.toPagedResponse(
                notificationRepository.findAllByUserId(userId, pageable).map(NotificationResponse::from)
        );
    }

    @Transactional
    public NotificationResponse markAsRead(Long id, Long userId) {
        Notification notification = notificationRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        notification.setIsRead(true);
        notification.setReadAt(LocalDateTime.now());
        return NotificationResponse.from(notificationRepository.save(notification));
    }

    @Transactional
    public void deleteNotification(Long id, Long userId) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        if (!notification.getUser().getId().equals(userId)) {
            throw new ForbiddenException("Cannot delete another user's notification");
        }
        notificationRepository.delete(notification);
    }
}
