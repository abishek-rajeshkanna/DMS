package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.Order;
import com.hyundai.DMS.domain.enums.OrderStatus;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDate;

public class OrderSpecification {

    private OrderSpecification() {}

    public static Specification<Order> hasDealership(Long dealershipId) {
        return (root, query, cb) -> dealershipId == null ? null
                : cb.equal(root.get("dealership").get("id"), dealershipId);
    }

    public static Specification<Order> hasStatus(OrderStatus status) {
        return (root, query, cb) -> status == null ? null
                : cb.equal(root.get("status"), status);
    }

    public static Specification<Order> hasCustomer(Long customerId) {
        return (root, query, cb) -> customerId == null ? null
                : cb.equal(root.get("customer").get("id"), customerId);
    }

    public static Specification<Order> hasSalesperson(Long salespersonId) {
        return (root, query, cb) -> salespersonId == null ? null
                : cb.equal(root.get("salesperson").get("id"), salespersonId);
    }

    public static Specification<Order> orderDateAfter(LocalDate from) {
        return (root, query, cb) -> from == null ? null
                : cb.greaterThanOrEqualTo(root.get("orderDate"), from);
    }

    public static Specification<Order> orderDateBefore(LocalDate to) {
        return (root, query, cb) -> to == null ? null
                : cb.lessThanOrEqualTo(root.get("orderDate"), to);
    }
}
