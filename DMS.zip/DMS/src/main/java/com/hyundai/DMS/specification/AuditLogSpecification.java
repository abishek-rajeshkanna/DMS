package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.AuditLog;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;

public class AuditLogSpecification {

    private AuditLogSpecification() {}

    public static Specification<AuditLog> hasUserId(Long userId) {
        return (root, query, cb) -> userId == null ? null : cb.equal(root.get("userId"), userId);
    }

    public static Specification<AuditLog> hasDealershipId(Long dealershipId) {
        return (root, query, cb) -> dealershipId == null ? null : cb.equal(root.get("dealershipId"), dealershipId);
    }

    public static Specification<AuditLog> hasAction(String action) {
        return (root, query, cb) -> action == null ? null : cb.equal(root.get("action"), action);
    }

    public static Specification<AuditLog> hasTableName(String tableName) {
        return (root, query, cb) -> tableName == null ? null : cb.equal(root.get("tableName"), tableName);
    }

    public static Specification<AuditLog> hasRecordId(Long recordId) {
        return (root, query, cb) -> recordId == null ? null : cb.equal(root.get("recordId"), recordId);
    }

    public static Specification<AuditLog> createdAfter(LocalDateTime from) {
        return (root, query, cb) -> from == null ? null : cb.greaterThanOrEqualTo(root.get("createdAt"), from);
    }

    public static Specification<AuditLog> createdBefore(LocalDateTime to) {
        return (root, query, cb) -> to == null ? null : cb.lessThanOrEqualTo(root.get("createdAt"), to);
    }
}
