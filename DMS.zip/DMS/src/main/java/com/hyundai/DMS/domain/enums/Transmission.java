package com.hyundai.DMS.domain.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum Transmission {
    MANUAL("manual"),
    AUTOMATIC("automatic"),
    CVT("cvt"),
    AMT("amt")
    ;

    private final String value;

    Transmission(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }
}
