package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.Payment;
import com.hyundai.DMS.domain.enums.PaymentMethod;
import com.hyundai.DMS.domain.enums.PaymentStatus;
import org.springframework.data.jpa.domain.Specification;

public class PaymentSpecification {

    private PaymentSpecification() {}

    public static Specification<Payment> hasOrder(Long orderId) {
        return (root, query, cb) -> orderId == null ? null
                : cb.equal(root.get("order").get("id"), orderId);
    }

    public static Specification<Payment> hasStatus(PaymentStatus status) {
        return (root, query, cb) -> status == null ? null
                : cb.equal(root.get("status"), status);
    }

    public static Specification<Payment> hasMethod(PaymentMethod method) {
        return (root, query, cb) -> method == null ? null
                : cb.equal(root.get("method"), method);
    }
}
