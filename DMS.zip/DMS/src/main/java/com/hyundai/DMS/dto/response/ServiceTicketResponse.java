package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.ServiceTicket;
import com.hyundai.DMS.domain.enums.ServicePriority;
import com.hyundai.DMS.domain.enums.ServiceTicketStatus;
import com.hyundai.DMS.domain.enums.ServiceType;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
public class ServiceTicketResponse {
    private Long id;
    private Long dealershipId;
    private String ticketNumber;
    private Long customerId;
    private String customerName;
    private Long assignedToId;
    private String assignedToName;
    private String vehicleMake;
    private String vehicleModel;
    private Integer vehicleYear;
    private String vehicleVin;
    private String licensePlate;
    private Integer odometerIn;
    private Integer odometerOut;
    private ServiceTicketStatus status;
    private ServicePriority priority;
    private ServiceType serviceType;
    private String diagnosis;
    private Boolean customerApproval;
    private LocalDateTime dropOffAt;
    private LocalDateTime promisedAt;
    private LocalDateTime completedAt;
    private LocalDateTime deliveredAt;
    private BigDecimal totalParts;
    private BigDecimal totalLabor;
    private BigDecimal totalCost;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static ServiceTicketResponse from(ServiceTicket t) {
        return ServiceTicketResponse.builder()
                .id(t.getId())
                .dealershipId(t.getDealership() != null ? t.getDealership().getId() : null)
                .ticketNumber(t.getTicketNumber())
                .customerId(t.getCustomer() != null ? t.getCustomer().getId() : null)
                .customerName(t.getCustomer() != null
                        ? t.getCustomer().getFirstName() + " " + t.getCustomer().getLastName() : null)
                .assignedToId(t.getAssignedTo() != null ? t.getAssignedTo().getId() : null)
                .assignedToName(t.getAssignedTo() != null
                        ? t.getAssignedTo().getFirstName() + " " + t.getAssignedTo().getLastName() : null)
                .vehicleMake(t.getVehicleMake())
                .vehicleModel(t.getVehicleModel())
                .vehicleYear(t.getVehicleYear())
                .vehicleVin(t.getVehicleVin())
                .licensePlate(t.getLicensePlate())
                .odometerIn(t.getOdometerIn())
                .odometerOut(t.getOdometerOut())
                .status(t.getStatus())
                .priority(t.getPriority())
                .serviceType(t.getServiceType())
                .diagnosis(t.getDiagnosis())
                .customerApproval(t.getCustomerApproval())
                .dropOffAt(t.getDropOffAt())
                .promisedAt(t.getPromisedAt())
                .completedAt(t.getCompletedAt())
                .deliveredAt(t.getDeliveredAt())
                .totalParts(t.getTotalParts())
                .totalLabor(t.getTotalLabor())
                .totalCost(t.getTotalCost())
                .notes(t.getNotes())
                .createdAt(t.getCreatedAt())
                .updatedAt(t.getUpdatedAt())
                .build();
    }
}
