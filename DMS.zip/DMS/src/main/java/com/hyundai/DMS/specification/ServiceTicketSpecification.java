package com.hyundai.DMS.specification;

import com.hyundai.DMS.domain.entity.ServiceTicket;
import com.hyundai.DMS.domain.enums.ServicePriority;
import com.hyundai.DMS.domain.enums.ServiceTicketStatus;
import com.hyundai.DMS.domain.enums.ServiceType;
import org.springframework.data.jpa.domain.Specification;

public class ServiceTicketSpecification {

    private ServiceTicketSpecification() {}

    public static Specification<ServiceTicket> hasDealership(Long dealershipId) {
        return (root, query, cb) -> dealershipId == null ? null
                : cb.equal(root.get("dealership").get("id"), dealershipId);
    }

    public static Specification<ServiceTicket> hasStatus(ServiceTicketStatus status) {
        return (root, query, cb) -> status == null ? null
                : cb.equal(root.get("status"), status);
    }

    public static Specification<ServiceTicket> hasPriority(ServicePriority priority) {
        return (root, query, cb) -> priority == null ? null
                : cb.equal(root.get("priority"), priority);
    }

    public static Specification<ServiceTicket> hasServiceType(ServiceType serviceType) {
        return (root, query, cb) -> serviceType == null ? null
                : cb.equal(root.get("serviceType"), serviceType);
    }

    public static Specification<ServiceTicket> assignedTo(Long userId) {
        return (root, query, cb) -> userId == null ? null
                : cb.equal(root.get("assignedTo").get("id"), userId);
    }

    public static Specification<ServiceTicket> hasCustomer(Long customerId) {
        return (root, query, cb) -> customerId == null ? null
                : cb.equal(root.get("customer").get("id"), customerId);
    }
}
