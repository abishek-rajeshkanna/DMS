package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.RefreshToken;
import com.hyundai.DMS.domain.entity.User;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.repository.RefreshTokenRepository;
import com.hyundai.DMS.security.DmsUserDetails;
import com.hyundai.DMS.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TokenService {

    private final JwtService jwtService;
    private final RefreshTokenRepository refreshTokenRepository;

    @Value("${app.jwt.refresh-token-expiry}")
    private long refreshTokenExpiry; // seconds

    public record TokenPair(String accessToken, String refreshToken) {}

    @Transactional
    public TokenPair issueTokenPair(User user) {
        DmsUserDetails userDetails = new DmsUserDetails(user);
        String accessToken = jwtService.generateAccessToken(userDetails);
        String rawRefresh = jwtService.generateRefreshToken();
        String tokenHash = sha256(rawRefresh);

        RefreshToken entity = RefreshToken.builder()
                .user(user)
                .tokenHash(tokenHash)
                .expiresAt(LocalDateTime.now().plusSeconds(refreshTokenExpiry))
                .isRevoked(false)
                .build();
        refreshTokenRepository.save(entity);

        return new TokenPair(accessToken, rawRefresh);
    }

    @Transactional
    public TokenPair refreshTokens(String rawRefreshToken) {
        String hash = sha256(rawRefreshToken);
        RefreshToken stored = refreshTokenRepository.findByTokenHash(hash)
                .orElseThrow(() -> new ResourceNotFoundException("Refresh token not found"));

        boolean revoked = Boolean.TRUE.equals(stored.getIsRevoked());
        boolean expired = stored.getExpiresAt() != null && stored.getExpiresAt().isBefore(LocalDateTime.now());

        if (revoked || expired) {
            throw new ResourceNotFoundException("Refresh token is expired or revoked");
        }

        // Rotate: revoke old, issue new pair
        stored.setIsRevoked(true);
        stored.setRevokedAt(LocalDateTime.now());
        refreshTokenRepository.save(stored);

        return issueTokenPair(stored.getUser());
    }

    @Transactional
    public void revokeAllForUser(Long userId) {
        List<RefreshToken> active = refreshTokenRepository.findAllByUserIdAndIsRevokedFalse(userId);
        LocalDateTime now = LocalDateTime.now();
        active.forEach(t -> {
            t.setIsRevoked(true);
            t.setRevokedAt(now);
        });
        refreshTokenRepository.saveAll(active);
    }

    public String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }
}
