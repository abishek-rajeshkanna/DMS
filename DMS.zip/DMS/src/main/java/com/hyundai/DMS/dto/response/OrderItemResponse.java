package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.OrderItem;
import com.hyundai.DMS.domain.enums.OrderItemType;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
public class OrderItemResponse {
    private Long id;
    private Long orderId;
    private OrderItemType itemType;
    private Long inventoryId;
    private String description;
    private BigDecimal unitPrice;
    private Integer quantity;
    private BigDecimal discount;
    private BigDecimal lineTotal;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static OrderItemResponse from(OrderItem i) {
        return OrderItemResponse.builder()
                .id(i.getId())
                .orderId(i.getOrder() != null ? i.getOrder().getId() : null)
                .itemType(i.getItemType())
                .inventoryId(i.getInventory() != null ? i.getInventory().getId() : null)
                .description(i.getDescription())
                .unitPrice(i.getUnitPrice())
                .quantity(i.getQuantity())
                .discount(i.getDiscount())
                .lineTotal(i.getLineTotal())
                .createdAt(i.getCreatedAt())
                .updatedAt(i.getUpdatedAt())
                .build();
    }
}
