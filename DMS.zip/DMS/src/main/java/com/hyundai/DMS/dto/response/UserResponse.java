package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.User;
import com.hyundai.DMS.domain.enums.Role;
import com.hyundai.DMS.domain.enums.UserStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class UserResponse {
    private Long id;
    private Long dealershipId;
    private String dealershipName;
    private String firstName;
    private String lastName;
    private String email;
    private Role role;
    private UserStatus status;
    private LocalDateTime lastLogin;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static UserResponse from(User u) {
        return UserResponse.builder()
                .id(u.getId())
                .dealershipId(u.getDealership() != null ? u.getDealership().getId() : null)
                .dealershipName(u.getDealership() != null ? u.getDealership().getName() : null)
                .firstName(u.getFirstName())
                .lastName(u.getLastName())
                .email(u.getEmail())
                .role(u.getRole())
                .status(u.getStatus())
                .lastLogin(u.getLastLogin())
                .createdAt(u.getCreatedAt())
                .updatedAt(u.getUpdatedAt())
                .build();
    }
}
