package com.hyundai.DMS.service;

import com.hyundai.DMS.domain.entity.*;
import com.hyundai.DMS.domain.enums.InventoryStatus;
import com.hyundai.DMS.domain.enums.OrderItemType;
import com.hyundai.DMS.domain.enums.OrderStatus;
import com.hyundai.DMS.dto.request.OrderFilter;
import com.hyundai.DMS.dto.request.OrderRequest;
import com.hyundai.DMS.dto.response.OrderResponse;
import com.hyundai.DMS.dto.response.PagedResponse;
import com.hyundai.DMS.exception.ConflictException;
import com.hyundai.DMS.exception.ForbiddenException;
import com.hyundai.DMS.exception.ResourceNotFoundException;
import com.hyundai.DMS.exception.ValidationException;
import com.hyundai.DMS.repository.*;
import com.hyundai.DMS.security.DmsUserDetails;
import com.hyundai.DMS.specification.OrderSpecification;
import com.hyundai.DMS.util.PaginationUtils;
import com.hyundai.DMS.util.SequenceGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;
    private final DealershipRepository dealershipRepository;
    private final InventoryRepository inventoryRepository;
    private final SequenceGenerator sequenceGenerator;
    private final AuditService auditService;

    @Transactional
    public OrderResponse createOrder(OrderRequest request, DmsUserDetails principal) {
        Dealership dealership = dealershipRepository.findById(request.getDealershipId())
                .orElseThrow(() -> new ResourceNotFoundException("Dealership not found"));

        if (!principal.isSuperAdmin() && !dealership.getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Cannot create order in another dealership");
        }

        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));

        User salesperson = userRepository.findById(request.getSalespersonId())
                .orElseThrow(() -> new ResourceNotFoundException("Salesperson not found"));

        String orderNumber = sequenceGenerator.nextOrderNumber(
                request.getOrderDate() != null ? request.getOrderDate() : LocalDate.now());

        Order order = Order.builder()
                .dealership(dealership)
                .orderNumber(orderNumber)
                .customer(customer)
                .salesperson(salesperson)
                .status(OrderStatus.DRAFT)
                .orderDate(request.getOrderDate() != null ? request.getOrderDate() : LocalDate.now())
                .subtotal(BigDecimal.ZERO)
                .discountAmount(request.getDiscountAmount() != null ? request.getDiscountAmount() : BigDecimal.ZERO)
                .taxRate(request.getTaxRate() != null ? request.getTaxRate() : BigDecimal.ZERO)
                .taxAmount(BigDecimal.ZERO)
                .tradeInValue(request.getTradeInValue() != null ? request.getTradeInValue() : BigDecimal.ZERO)
                .totalAmount(BigDecimal.ZERO)
                .notes(request.getNotes())
                .build();

        order = orderRepository.save(order);
        auditService.log(principal.getUserId(), dealership.getId(), "CREATE_ORDER",
                "orders", order.getId(), null, null, null, null);

        return OrderResponse.from(order);
    }

    public PagedResponse<OrderResponse> listOrders(OrderFilter filter, Pageable pageable, DmsUserDetails principal) {
        if (!principal.isSuperAdmin()) {
            filter.setDealershipId(principal.getDealershipId());
        }

        Specification<Order> spec = Specification
                .where(OrderSpecification.hasDealership(filter.getDealershipId()))
                .and(OrderSpecification.hasStatus(filter.getStatus()))
                .and(OrderSpecification.hasCustomer(filter.getCustomerId()))
                .and(OrderSpecification.hasSalesperson(filter.getSalespersonId()))
                .and(OrderSpecification.orderDateAfter(filter.getOrderDateFrom()))
                .and(OrderSpecification.orderDateBefore(filter.getOrderDateTo()));

        return PaginationUtils.toPagedResponse(
                orderRepository.findAll(spec, pageable).map(OrderResponse::from)
        );
    }

    public OrderResponse getOrder(Long id, DmsUserDetails principal) {
        Order order = findById(id);
        enforceScope(order, principal);
        return OrderResponse.from(order);
    }

    @Transactional
    public OrderResponse updateOrder(Long id, OrderRequest request, DmsUserDetails principal) {
        Order order = findById(id);
        enforceScope(order, principal);

        if (order.getStatus() != OrderStatus.DRAFT) {
            throw new ConflictException("Only draft orders can be updated");
        }

        order.setDiscountAmount(request.getDiscountAmount() != null ? request.getDiscountAmount() : BigDecimal.ZERO);
        order.setTaxRate(request.getTaxRate() != null ? request.getTaxRate() : BigDecimal.ZERO);
        order.setTradeInValue(request.getTradeInValue() != null ? request.getTradeInValue() : BigDecimal.ZERO);
        order.setNotes(request.getNotes());

        recomputeFinancials(order);
        order = orderRepository.save(order);

        auditService.log(principal.getUserId(), order.getDealership().getId(), "UPDATE_ORDER",
                "orders", order.getId(), null, null, null, null);

        return OrderResponse.from(order);
    }

    @Transactional
    public OrderResponse transitionStatus(Long id, OrderStatus newStatus, String cancellationReason, DmsUserDetails principal) {
        Order order = findById(id);
        enforceScope(order, principal);

        if (newStatus == OrderStatus.CANCELLED && (cancellationReason == null || cancellationReason.isBlank())) {
            throw new ValidationException("Cancellation reason is required when cancelling an order");
        }

        // Sync inventory status based on order transition
        List<OrderItem> items = orderItemRepository.findAllByOrderId(order.getId());
        for (OrderItem item : items) {
            if (item.getItemType() == OrderItemType.VEHICLE && item.getInventory() != null) {
                Inventory inv = item.getInventory();
                if (newStatus == OrderStatus.CONFIRMED) {
                    inv.setStatus(InventoryStatus.RESERVED);
                    inventoryRepository.save(inv);
                } else if (newStatus == OrderStatus.DELIVERED) {
                    inv.setStatus(InventoryStatus.SOLD);
                    inventoryRepository.save(inv);
                } else if (newStatus == OrderStatus.CANCELLED) {
                    inv.setStatus(InventoryStatus.AVAILABLE);
                    inventoryRepository.save(inv);
                }
            }
        }

        order.setStatus(newStatus);
        if (newStatus == OrderStatus.CANCELLED) {
            order.setCancellationReason(cancellationReason);
        }

        order = orderRepository.save(order);
        auditService.log(principal.getUserId(), order.getDealership().getId(), "TRANSITION_ORDER_STATUS",
                "orders", order.getId(), null, null, null, null);

        return OrderResponse.from(order);
    }

    public void recomputeFinancials(Order order) {
        List<OrderItem> items = orderItemRepository.findAllByOrderId(order.getId());
        BigDecimal subtotal = items.stream()
                .map(OrderItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal discount = order.getDiscountAmount() != null ? order.getDiscountAmount() : BigDecimal.ZERO;
        BigDecimal taxRate = order.getTaxRate() != null ? order.getTaxRate() : BigDecimal.ZERO;
        BigDecimal tradeIn = order.getTradeInValue() != null ? order.getTradeInValue() : BigDecimal.ZERO;

        BigDecimal taxableAmount = subtotal.subtract(discount);
        BigDecimal taxAmount = taxableAmount.multiply(taxRate).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        BigDecimal total = taxableAmount.add(taxAmount).subtract(tradeIn);

        order.setSubtotal(subtotal);
        order.setTaxAmount(taxAmount);
        order.setTotalAmount(total.max(BigDecimal.ZERO));
    }

    private void enforceScope(Order order, DmsUserDetails principal) {
        if (principal.isSuperAdmin()) return;
        if (!order.getDealership().getId().equals(principal.getDealershipId())) {
            throw new ForbiddenException("Access denied to order in another dealership");
        }
    }

    public Order findById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + id));
    }
}
