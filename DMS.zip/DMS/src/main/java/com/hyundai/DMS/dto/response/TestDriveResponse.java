package com.hyundai.DMS.dto.response;

import com.hyundai.DMS.domain.entity.TestDrive;
import com.hyundai.DMS.domain.enums.TestDriveStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class TestDriveResponse {
    private Long id;
    private Long dealershipId;
    private Long customerId;
    private String customerName;
    private Long inventoryId;
    private String vehicleSummary;
    private Long staffId;
    private String staffName;
    private LocalDateTime scheduledAt;
    private LocalDateTime startedAt;
    private LocalDateTime endedAt;
    private TestDriveStatus status;
    private Integer odometerBefore;
    private Integer odometerAfter;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static TestDriveResponse from(TestDrive t) {
        return TestDriveResponse.builder()
                .id(t.getId())
                .dealershipId(t.getDealership() != null ? t.getDealership().getId() : null)
                .customerId(t.getCustomer() != null ? t.getCustomer().getId() : null)
                .customerName(t.getCustomer() != null
                        ? t.getCustomer().getFirstName() + " " + t.getCustomer().getLastName() : null)
                .inventoryId(t.getInventory() != null ? t.getInventory().getId() : null)
                .vehicleSummary(t.getInventory() != null
                        ? t.getInventory().getYear() + " " + t.getInventory().getMake() + " " + t.getInventory().getModel() : null)
                .staffId(t.getStaff() != null ? t.getStaff().getId() : null)
                .staffName(t.getStaff() != null
                        ? t.getStaff().getFirstName() + " " + t.getStaff().getLastName() : null)
                .scheduledAt(t.getScheduledAt())
                .startedAt(t.getStartedAt())
                .endedAt(t.getEndedAt())
                .status(t.getStatus())
                .odometerBefore(t.getOdometerBefore())
                .odometerAfter(t.getOdometerAfter())
                .notes(t.getNotes())
                .createdAt(t.getCreatedAt())
                .updatedAt(t.getUpdatedAt())
                .build();
    }
}
