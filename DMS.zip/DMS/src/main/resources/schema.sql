-- Dealer Management System - Database Schema
-- All tables use InnoDB engine with utf8mb4 charset

-- 1. dealerships
CREATE TABLE IF NOT EXISTS dealerships (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    phone       VARCHAR(20)  NOT NULL,
    address     TEXT,
    city        VARCHAR(100),
    state       VARCHAR(100),
    license_no  VARCHAR(100) NOT NULL UNIQUE,
    is_active   TINYINT(1)   NOT NULL DEFAULT 1,
    created_at  DATETIME     NOT NULL,
    updated_at  DATETIME     NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_dealerships_city_state ON dealerships (city, state);
CREATE INDEX idx_dealerships_is_active  ON dealerships (is_active);

-- 2. users
CREATE TABLE IF NOT EXISTS users (
    id                     BIGINT AUTO_INCREMENT PRIMARY KEY,
    dealership_id          BIGINT,
    first_name             VARCHAR(100) NOT NULL,
    last_name              VARCHAR(100) NOT NULL,
    email                  VARCHAR(150) NOT NULL UNIQUE,
    password_hash          VARCHAR(255) NOT NULL,
    role                   ENUM('super_admin','admin','manager','salesperson','technician','receptionist') NOT NULL,
    status                 ENUM('active','inactive','suspended') NOT NULL DEFAULT 'active',
    failed_login_attempts  INT      NOT NULL DEFAULT 0,
    locked_until           DATETIME NULL,
    last_login             DATETIME NULL,
    password_changed_at    DATETIME NULL,
    created_at             DATETIME NOT NULL,
    updated_at             DATETIME NOT NULL,
    CONSTRAINT fk_users_dealership FOREIGN KEY (dealership_id) REFERENCES dealerships (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_users_email            ON users (email);
CREATE INDEX idx_users_dealership_role  ON users (dealership_id, role);
CREATE INDEX idx_users_status           ON users (status);

-- 3. refresh_tokens
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT       NOT NULL,
    token_hash  VARCHAR(64)  NOT NULL UNIQUE,
    expires_at  DATETIME     NOT NULL,
    is_revoked  TINYINT(1)   NOT NULL DEFAULT 0,
    revoked_at  DATETIME     NULL,
    created_at  DATETIME     NOT NULL,
    CONSTRAINT fk_refresh_tokens_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_refresh_tokens_user_id    ON refresh_tokens (user_id);
CREATE INDEX idx_refresh_tokens_token_hash ON refresh_tokens (token_hash);

-- 4. inventory
CREATE TABLE IF NOT EXISTS inventory (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    dealership_id   BIGINT       NOT NULL,
    vin             VARCHAR(17)  NOT NULL UNIQUE,
    make            VARCHAR(100) NOT NULL,
    model           VARCHAR(100) NOT NULL,
    variant         VARCHAR(100),
    year            SMALLINT     NOT NULL,
    fuel_type       ENUM('petrol','diesel','electric','hybrid','cng') NOT NULL,
    transmission    ENUM('manual','automatic','cvt','amt') NOT NULL,
    body_type       ENUM('sedan','suv','hatchback','coupe','convertible','van','truck','wagon'),
    color           VARCHAR(50),
    mileage         INT          NOT NULL DEFAULT 0,
    condition_type  ENUM('new','used','certified_pre_owned') NOT NULL,
    status          ENUM('available','reserved','test_drive','sold','inactive') NOT NULL DEFAULT 'available',
    cost_price      DECIMAL(12,2) NOT NULL,
    selling_price   DECIMAL(12,2) NOT NULL,
    intake_date     DATE         NOT NULL,
    notes           TEXT,
    created_at      DATETIME     NOT NULL,
    updated_at      DATETIME     NOT NULL,
    CONSTRAINT fk_inventory_dealership FOREIGN KEY (dealership_id) REFERENCES dealerships (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_inventory_dealership_status ON inventory (dealership_id, status);
CREATE INDEX idx_inventory_make_model        ON inventory (make, model);
CREATE INDEX idx_inventory_vin               ON inventory (vin);
CREATE INDEX idx_inventory_selling_price     ON inventory (selling_price);
CREATE INDEX idx_inventory_year              ON inventory (year);

-- 5. inventory_history
CREATE TABLE IF NOT EXISTS inventory_history (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    inventory_id  BIGINT       NOT NULL,
    field_name    VARCHAR(100) NOT NULL,
    old_value     TEXT,
    new_value     TEXT,
    changed_by    BIGINT       NOT NULL,
    reason        TEXT,
    created_at    DATETIME     NOT NULL,
    CONSTRAINT fk_inv_history_inventory FOREIGN KEY (inventory_id) REFERENCES inventory (id),
    CONSTRAINT fk_inv_history_user      FOREIGN KEY (changed_by)   REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_inv_history_inventory_id ON inventory_history (inventory_id);
CREATE INDEX idx_inv_history_created_at   ON inventory_history (created_at);

-- 6. customers
CREATE TABLE IF NOT EXISTS customers (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    dealership_id  BIGINT       NOT NULL,
    first_name     VARCHAR(100) NOT NULL,
    last_name      VARCHAR(100) NOT NULL,
    email          VARCHAR(150),
    phone          VARCHAR(20)  NOT NULL,
    status         ENUM('lead','prospect','customer','lost') NOT NULL DEFAULT 'lead',
    source         VARCHAR(100),
    assigned_to    BIGINT       NULL,
    notes          TEXT,
    created_at     DATETIME     NOT NULL,
    updated_at     DATETIME     NOT NULL,
    CONSTRAINT fk_customers_dealership FOREIGN KEY (dealership_id) REFERENCES dealerships (id),
    CONSTRAINT fk_customers_assigned   FOREIGN KEY (assigned_to)   REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_customers_dealership_status ON customers (dealership_id, status);
CREATE INDEX idx_customers_assigned_to       ON customers (assigned_to);
CREATE INDEX idx_customers_phone             ON customers (phone);
CREATE INDEX idx_customers_email             ON customers (email);

-- 7. test_drives
CREATE TABLE IF NOT EXISTS test_drives (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    dealership_id   BIGINT   NOT NULL,
    customer_id     BIGINT   NOT NULL,
    inventory_id    BIGINT   NOT NULL,
    staff_id        BIGINT   NOT NULL,
    scheduled_at    DATETIME NOT NULL,
    started_at      DATETIME NULL,
    ended_at        DATETIME NULL,
    status          ENUM('scheduled','in_progress','completed','cancelled') NOT NULL DEFAULT 'scheduled',
    odometer_before INT      NULL,
    odometer_after  INT      NULL,
    notes           TEXT,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    CONSTRAINT fk_test_drives_dealership FOREIGN KEY (dealership_id) REFERENCES dealerships (id),
    CONSTRAINT fk_test_drives_customer   FOREIGN KEY (customer_id)   REFERENCES customers (id),
    CONSTRAINT fk_test_drives_inventory  FOREIGN KEY (inventory_id)  REFERENCES inventory (id),
    CONSTRAINT fk_test_drives_staff      FOREIGN KEY (staff_id)      REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_test_drives_inventory_id  ON test_drives (inventory_id);
CREATE INDEX idx_test_drives_customer_id   ON test_drives (customer_id);
CREATE INDEX idx_test_drives_staff_id      ON test_drives (staff_id);
CREATE INDEX idx_test_drives_scheduled_at  ON test_drives (scheduled_at);

-- 8. orders
CREATE TABLE IF NOT EXISTS `orders` (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    dealership_id       BIGINT        NOT NULL,
    order_number        VARCHAR(30)   NOT NULL UNIQUE,
    customer_id         BIGINT        NOT NULL,
    salesperson_id      BIGINT        NOT NULL,
    status              ENUM('draft','confirmed','processing','delivered','cancelled') NOT NULL DEFAULT 'draft',
    order_date          DATE          NOT NULL,
    subtotal            DECIMAL(14,2) NOT NULL DEFAULT 0,
    discount_amount     DECIMAL(14,2) NOT NULL DEFAULT 0,
    tax_rate            DECIMAL(5,2)  NOT NULL DEFAULT 0,
    tax_amount          DECIMAL(14,2) NOT NULL DEFAULT 0,
    trade_in_value      DECIMAL(14,2) NOT NULL DEFAULT 0,
    total_amount        DECIMAL(14,2) NOT NULL DEFAULT 0,
    cancellation_reason TEXT          NULL,
    notes               TEXT,
    created_at          DATETIME      NOT NULL,
    updated_at          DATETIME      NOT NULL,
    CONSTRAINT fk_orders_dealership  FOREIGN KEY (dealership_id)  REFERENCES dealerships (id),
    CONSTRAINT fk_orders_customer    FOREIGN KEY (customer_id)    REFERENCES customers (id),
    CONSTRAINT fk_orders_salesperson FOREIGN KEY (salesperson_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_orders_dealership_status ON `orders` (dealership_id, status);
CREATE INDEX idx_orders_customer_id       ON `orders` (customer_id);
CREATE INDEX idx_orders_salesperson_id    ON `orders` (salesperson_id);
CREATE INDEX idx_orders_order_date        ON `orders` (order_date);
CREATE INDEX idx_orders_order_number      ON `orders` (order_number);

-- 9. order_items
CREATE TABLE IF NOT EXISTS order_items (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id      BIGINT        NOT NULL,
    item_type     ENUM('vehicle','accessory','insurance','warranty','fee','other') NOT NULL,
    inventory_id  BIGINT        NULL,
    description   VARCHAR(255)  NOT NULL,
    unit_price    DECIMAL(12,2) NOT NULL,
    quantity      INT           NOT NULL DEFAULT 1,
    discount      DECIMAL(12,2) NOT NULL DEFAULT 0,
    line_total    DECIMAL(12,2) NOT NULL,
    created_at    DATETIME      NOT NULL,
    updated_at    DATETIME      NOT NULL,
    CONSTRAINT fk_order_items_order     FOREIGN KEY (order_id)     REFERENCES `orders` (id),
    CONSTRAINT fk_order_items_inventory FOREIGN KEY (inventory_id) REFERENCES inventory (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_order_items_order_id     ON order_items (order_id);
CREATE INDEX idx_order_items_inventory_id ON order_items (inventory_id);

-- 10. payments
CREATE TABLE IF NOT EXISTS payments (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id      BIGINT        NOT NULL,
    amount        DECIMAL(12,2) NOT NULL,
    method        ENUM('cash','card','bank_transfer','finance','cheque') NOT NULL,
    status        ENUM('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
    reference_no  VARCHAR(100)  NULL,
    notes         TEXT,
    paid_at       DATETIME      NULL,
    created_at    DATETIME      NOT NULL,
    updated_at    DATETIME      NOT NULL,
    CONSTRAINT fk_payments_order FOREIGN KEY (order_id) REFERENCES `orders` (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_payments_order_id ON payments (order_id);
CREATE INDEX idx_payments_status   ON payments (status);

-- 11. service_tickets
CREATE TABLE IF NOT EXISTS service_tickets (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    dealership_id       BIGINT        NOT NULL,
    ticket_number       VARCHAR(30)   NOT NULL UNIQUE,
    customer_id         BIGINT        NOT NULL,
    assigned_to         BIGINT        NULL,
    vehicle_make        VARCHAR(100),
    vehicle_model       VARCHAR(100),
    vehicle_year        SMALLINT,
    vehicle_vin         VARCHAR(17),
    license_plate       VARCHAR(20),
    odometer_in         INT           NULL,
    odometer_out        INT           NULL,
    status              ENUM('open','in_progress','completed','delivered','cancelled') NOT NULL DEFAULT 'open',
    priority            ENUM('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
    service_type        ENUM('maintenance','repair','inspection','recall','warranty','other') NOT NULL,
    diagnosis           TEXT          NULL,
    customer_approval   TINYINT(1)    NOT NULL DEFAULT 0,
    drop_off_at         DATETIME      NULL,
    promised_at         DATETIME      NULL,
    completed_at        DATETIME      NULL,
    delivered_at        DATETIME      NULL,
    total_parts         DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_labor         DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_cost          DECIMAL(12,2) NOT NULL DEFAULT 0,
    notes               TEXT,
    created_at          DATETIME      NOT NULL,
    updated_at          DATETIME      NOT NULL,
    CONSTRAINT fk_svc_tickets_dealership FOREIGN KEY (dealership_id) REFERENCES dealerships (id),
    CONSTRAINT fk_svc_tickets_customer   FOREIGN KEY (customer_id)   REFERENCES customers (id),
    CONSTRAINT fk_svc_tickets_assigned   FOREIGN KEY (assigned_to)   REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_svc_tickets_dealership_status ON service_tickets (dealership_id, status);
CREATE INDEX idx_svc_tickets_customer_id       ON service_tickets (customer_id);
CREATE INDEX idx_svc_tickets_assigned_to       ON service_tickets (assigned_to);
CREATE INDEX idx_svc_tickets_priority          ON service_tickets (priority);
CREATE INDEX idx_svc_tickets_ticket_number     ON service_tickets (ticket_number);

-- 12. service_items
CREATE TABLE IF NOT EXISTS service_items (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    ticket_id    BIGINT        NOT NULL,
    item_type    ENUM('part','labor','consumable','external') NOT NULL,
    description  VARCHAR(255)  NOT NULL,
    part_number  VARCHAR(100)  NULL,
    unit_cost    DECIMAL(10,2) NOT NULL,
    quantity     DECIMAL(10,3) NOT NULL DEFAULT 1,
    line_total   DECIMAL(12,2) NOT NULL,
    created_at   DATETIME      NOT NULL,
    updated_at   DATETIME      NOT NULL,
    CONSTRAINT fk_service_items_ticket FOREIGN KEY (ticket_id) REFERENCES service_tickets (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_service_items_ticket_id ON service_items (ticket_id);

-- 13. audit_logs
CREATE TABLE IF NOT EXISTS audit_logs (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id        BIGINT        NULL,
    dealership_id  BIGINT        NULL,
    action         VARCHAR(50)   NOT NULL,
    table_name     VARCHAR(100)  NULL,
    record_id      BIGINT        NULL,
    old_values     JSON          NULL,
    new_values     JSON          NULL,
    ip_address     VARCHAR(45)   NULL,
    user_agent     VARCHAR(500)  NULL,
    created_at     DATETIME      NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_audit_logs_user_id        ON audit_logs (user_id);
CREATE INDEX idx_audit_logs_dealership_id  ON audit_logs (dealership_id);
CREATE INDEX idx_audit_logs_action         ON audit_logs (action);
CREATE INDEX idx_audit_logs_table_record   ON audit_logs (table_name, record_id);
CREATE INDEX idx_audit_logs_created_at     ON audit_logs (created_at);

-- 14. notifications
CREATE TABLE IF NOT EXISTS notifications (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT        NOT NULL,
    title           VARCHAR(255)  NOT NULL,
    message         TEXT          NOT NULL,
    is_read         TINYINT(1)    NOT NULL DEFAULT 0,
    read_at         DATETIME      NULL,
    reference_type  VARCHAR(50)   NULL,
    reference_id    BIGINT        NULL,
    created_at      DATETIME      NOT NULL,
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_notifications_user_id_is_read ON notifications (user_id, is_read);
CREATE INDEX idx_notifications_created_at      ON notifications (created_at);
